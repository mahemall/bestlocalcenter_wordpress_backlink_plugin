<?php

//get_site_url();
//$wpdb->query($wpdb->prepare("$sql_1"));
function blcfblf_errors($num)
{
	switch($num)
	{
		case "1":
		{
			$msg ="Enter Valid email address";
			return $msg;
		}
		break;
		
		case "activateemail_exp1":
		{
			$msg =" Please enter valid email address . Verification code will be sent to email id that you enter below";
			return $msg;
		}
		break;
		
		
		default:
		{
			$msg ="unknown error occured. contact developer";
			return $msg;
		}
		break;
	}
}


function blcfblf_refreshuser()
{
	
	global $global_ar;
	global $wpdb;
	$user_auth = blcfblf_get_cred();
	$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				$id =$user_auth['id'];
	$curl_url=$global_ar['blcfblf_rest_rendpoint'].'userstatus.php';
	//echo $curl_url;
	$response = json_decode(makeapicall_post_plugin($curl_url, $json_array),true);
	/*
	echo '<pre>';
	print_r($response);
	echo '</pre>';
	*/
	if($response['status']=="1")
	{
		//update wp_blcfblf_auth
		$blcfblf_status = $response['blcfblf_status'];
		$blcfblf_balance = $response['blcfblf_balance'];
		$membertype = $response['membertype'];
		
		$sql_1='UPDATE wp_blcfblf_auth SET blcfblf_status = "'.$blcfblf_status.'", blcfblf_balance="'.$blcfblf_balance.'",membertype="'.$membertype.'" WHERE id  = "'.$id.'"';
		//echo $sql_1;
		
		$wpdb->query($wpdb->prepare("$sql_1"));
		
	
			
		$_SESSION['membertype'] = $membertype;	
		$_SESSION['blcfblf_status'] = $blcfblf_status;	
		$_SESSION['blcfblf_balance'] = $blcfblf_balance;	
		
		
		//dbDelta($sql_1);
		//exit;

	}
	else
	{
		echo "unable to connect to server . please contact network administrator";
		exit;
	}
	
}

//current url 

function blcfblf_currenturl()
{
 
    if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')   
         $url = "https://";   
    else  
         $url = "http://";   
    // Append the host(domain name, ip) to the URL.   
    $url.= $_SERVER['HTTP_HOST'];   
    
    // Append the requested resource location to the URL   
    $url.= $_SERVER['REQUEST_URI'];    
      
    return $url;  
  
}

function blcfblf_makeapicall_post($curl_url, $json_array)
{
	/*
 $form_data = json_decode($_POST['form_data']);
    $data = array(
        'email' => 'free.ibm@gmail.com',
        'domainname' => 'http://localhost/wp/',
          );
*/
//echo $curl_url;

$data = $json_array;
$ch = curl_init($curl_url);
# Setup request to send json via POST.
$payload = json_encode( $data );

curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','charst:UTF-8'));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
return $result;
//return json_decode($result);


}



function blcfblf_datetimedifference($date1,$date2)
{
	
$date1 = strtotime($date1);
$date2 = strtotime($date2);

return ($date1 - $date2);


}



function blcfblf_redirecturl($url)
{
	echo '<script> location.replace("'.$url.'"); </script>';
	exit;
}

function blcfblf_get_cred()
{
	global $wpdb;
	global $global_ar;
	require_once(ABSPATH.'wp-admin/includes/upgrade.php');
	$sql_1='select user from wp_blcfblf_auth WHERE user ="root"';
	$result = $wpdb->get_var($sql_1);
	if($result)
		{
			$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
			$result1 = $wpdb->get_results($sql_1);
			
			$cred['blcfblf_authcode']=$result1[0]->blcfblf_sauthcode;
			$cred['blcfblf_emailid']=$result1[0]->blcfblf_emailid;
			$cred['membertype']=$result1[0]->membertype;
			$cred['id']=$result1[0]->id;
			//var_dump($global_ar);
			//print_r($result1[0]->blcfblf_emailid);
		}
		else
		{
		$cred['blcfblf_authcode'] = "dummyauthcode";	
		$cred['blcfblf_emailid'] = "dummy@dummy.com";
		$cred['membertype'] = "free";
		}
		return $cred;
}


function blcfblf_get_cred1()
{
	global $wpdb;
	global $global_ar;
	require_once(ABSPATH.'wp-admin/includes/upgrade.php');
	$sql_1='select user from wp_blcfblf_auth WHERE user ="root"';
	$result = $wpdb->get_var($sql_1);
	if($result)
		{
			$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
			
			$result1 = $wpdb->get_results($sql_1);
			
			$cred['blcfblf_authcode']=$result1[0]->blcfblf_sauthcode;
			$cred['blcfblf_emailid']=$result1[0]->blcfblf_emailid;
			$cred['membertype']=$result1[0]->membertype;
			//var_dump($global_ar);
			//print_r($result1[0]->blcfblf_emailid);
		}
		else
		{
		$cred['blcfblf_authcode'] = "dummyauthcode";	
		$cred['blcfblf_emailid'] = "dummy@dummy.com";
		$cred['membertype'] = "free";
		}
		return $cred;
}


function makeapicall_post($curl_url, $json_string)
{
	$curl = curl_init($curl_url);
	// 1. Set the CURLOPT_RETURNTRANSFER option to true
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

// 2. Set the CURLOPT_POST option to true for POST request
curl_setopt($curl, CURLOPT_POST, true);

// 3. Set the request data as JSON using json_encode function
curl_setopt($curl, CURLOPT_POSTFIELDS,  json_encode($json_string));

// 4. Set custom headers for RapidAPI Auth and Content-Type header
curl_setopt($curl, CURLOPT_HTTPHEADER, [
  'X-RapidAPI-Host: kvstore.p.rapidapi.com',
  'X-RapidAPI-Key: [Input your RapidAPI Key Here]',
  'Content-Type: application/json'
]);

// Execute cURL request with all previous settings
$response = curl_exec($curl);

// Close cURL session
curl_close($curl);
//echo $response . PHP_EOL;

return $response;
	
}



function blcfblf_d_site_headermenu_gray($details,$mem_type,$status,$action_type)
{
	echo '
	<style>
	.fakeimg {
    height: 200px;
    background: #aaa;
    
  }
.bgimg{
         background-color:black;
        background-repeat: no-repeat;
        background-size: 100% 100%;
        background-position: center;
      }
      .row{
          display: flex;
      }
 
 .jumbotron{
height:auto;
padding:5px 0 !important;
 }
	</style>
	
	<div class="jumbotron">
  <h2>'.$details.'</h2>
  <p>
  you are currently using <strong>'.$_SESSION["membertype"].' </strong>Account type . Site status is <strong>'.$_SESSION["blcfblf_status"].'</strong>. To Enjoy all the benifits <a href="'.get_site_url().'/wp-admin/admin.php?page=blcfblf_activate"><button type="button" class="btn btn-danger">'.$action_type.'</button></a>
  </p>

</div>
	
	';
}


function blcfblf_d_site_headermenu_gray_nosubmenu($details,$mem_type,$status,$action_type)
{
	echo '
	<style>
	.fakeimg {
    height: 200px;
    background: #aaa;
    
  }
.bgimg{
         background-color:black;
        background-repeat: no-repeat;
        background-size: 100% 100%;
        background-position: center;
      }
      .row{
          display: flex;
      }
 
 .jumbotron{
height:auto;
padding:5px 0 !important;
 }
	</style>
	
	<div class="jumbotron">
  <h2>'.$details.'</h2>
  <p>
  Please enter valid email id to activate plugin. A verification code will be sent to email id mentioned below.
  </p>

</div>
	
	';
}

function bootstrat_css()
{
	echo '
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>';
}


function blcfblf_d_sub_headermenu1_blue($head)
{
	//echo '<p class="bg-secondary text-white">'.$head.'</p>';
	echo ' <p class="text-primary">'.$head.'</p>';
}


function blcfblf_d_sub_headermenu1_red($head)
{
	//echo '<p class="bg-secondary text-white">'.$head.'</p>';
	echo ' <p class="text-danger">'.$head.'</p>';
}

function check_off_opt_rep_by_acamp_id($acamp_id)
{
	$data= array();
	//$acamp_id = "2";
	global $wpdb;
	//$sql_1 = "select off_opt_rep_status FROM wp_off_opt_rep WHERE acamp_id='$acamp_id'";
	$sql_1 = "select * FROM wp_off_opt_rep WHERE acamp_id='$acamp_id'";
	//$result = $wpdb->get_results($sql_1);
	$result = $wpdb->get_results($sql_1);
	if($result == null)
	{
		$data['entry'] = 0;
	}
	Else
	{
		$data['entry'] = 1;
		$data['result'] =$result[0];
	}
	return $data;
	
}

function check_fbacklink_by_acamp_id($acamp_id)
{
	$data= array();
	//$acamp_id = "2";
	global $wpdb;
	//$sql_1 = "select off_opt_rep_status FROM wp_off_opt_rep WHERE acamp_id='$acamp_id'";
	$sql_1 = "select * FROM wp_blcfblf_fbacklink WHERE acamp_id='$acamp_id'";
	//$result = $wpdb->get_results($sql_1);
	$result = $wpdb->get_results($sql_1);
	if($result == null)
	{
		$data['entry'] = 0;
	}
	Else
	{
		$data['entry'] = 1;
		$data['result'] =$result[0];
	}
	return $data;
	
}


function get_off_opt_rep_by_off_opt_rep_id($off_opt_rep_id)
{
	$data= array();
	//$acamp_id = "2";
	global $wpdb;
	$sql_1 = "select * FROM wp_off_opt_rep WHERE off_opt_rep_id='$off_opt_rep_id' ORDER BY lastupdate_time DESC";

	$result = $wpdb->get_results($sql_1);
	if($result == null)
	{
		$data['entry'] = 0;
	}
	Else
	{
		$data['entry'] = 1;
		$data['result'] =$result;
	}
	return $data;
	
}


function get_fbacklink_by_fbacklink_id($fbacklink_id)
{
	$data= array();
	//$acamp_id = "2";
	global $wpdb;
	$sql_1 = "select * FROM wp_blcfblf_fbacklink WHERE fbacklink_id='$fbacklink_id' ORDER BY lastupdate_time DESC";

	$result = $wpdb->get_results($sql_1);
	if($result == null)
	{
		$data['entry'] = 0;
	}
	Else
	{
		$data['entry'] = 1;
		$data['result'] =$result;
	}
	return $data;
	
}


function blcfblf_get_acamp_from_acamp_id($acamp_id)
{
	$data= array();
	//$acamp_id = "2";
	global $wpdb;
	$sql_1 = "select * FROM wp_blcfblf_addcampaing WHERE acamp_id='$acamp_id'";
	$result = $wpdb->get_results($sql_1);
	if($result == null)
	{
		$data['entry'] = 0;
	}
	Else
	{
		$data['entry'] = 1;
		$data['result'] =$result;
	}
	return $data;
	
}


function blcfblf_preloadergif_start_css()
{
	echo '
	<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.loader {
	margin-left: auto;
  margin-right: auto;
  border: 16px solid #f3f3f3;
  border-radius: 50%;
  border-top: 16px solid #3498db;
  width: 120px;
  height: 120px;
  -webkit-animation: spin 0.5s linear infinite; /* Safari */
  animation: spin 0.5s linear infinite;
}

/* Safari */
@-webkit-keyframes spin {
  0% { -webkit-transform: rotate(0deg); }
  100% { -webkit-transform: rotate(360deg); }
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}
</style>
</head>
<body>

<div class="loader" align="center"></div>

</body>
</html>

	';
}

function blcfblf_preloadergif_end()
{
	//java script code to over write element
}

function blcfblf_html_generate_off_opt_rep_report($off_opt_rep_status,$off_opt_rep_id)
{
echo '
<tr>
<td>
<h6>Report Status : </h5>
</td>
<td>
';
 //echo $off_opt_rep_id_forid->off_opt_rep_status;
 if($off_opt_rep_status =="pending")
 {
	 echo " you have not analysed this page yet, click below to generate report. ";
	  echo '
 </td>
</tr>
 ';
 echo '
<tr>
<td>
<h6></h6>
</td>
<td>
';
	 echo'
	 <script>
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="create_servertask"/>
    <input type="hidden" name="task_type" value="off_opt_rep"/>
    <input type="hidden" name="service_primaryid" value="'.$off_opt_rep_id.'"/>
	 <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Generate report </button>
	 </form>
	 
	 ';
	 	  echo '
 </td>
</tr>
 ';
 }

	
}

function blcfblf_html_generate_fbacklink_report($fbacklink_status,$fbacklink_id)
{
echo '
<tr>
<td>
<h6>Report Status : </h5>
</td>
<td>
';
 //echo $off_opt_rep_id_forid->off_opt_rep_status;
 if($fbacklink_status =="pending")
 {
	 echo " you have not analysed this page yet, click below to generate report. ";
	  echo '
 </td>
</tr>
 ';
 echo '
<tr>
<td>
<h6></h6>
</td>
<td>
';
	 echo'
	 <script>
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="create_servertask"/>
    <input type="hidden" name="task_type" value="fbacklink"/>
    <input type="hidden" name="current_url" value="'.blcfblf_currenturl().'"/>
    <input type="hidden" name="service_primaryid" value="'.$fbacklink_id.'"/>
	 <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Find Backlinks </button>
	 </form>
	 
	 ';
	 	  echo '
 </td>
</tr>
 ';
 }

	
}

function blcfblf_html_css_saveprimword(){
	
	echo '
	
	<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
	';
}

function blcfblf_html_saveprimword_savekeywordform_locked($add_campdetails)
{
	 echo'
	 <script>
	 function myFunction1(){
    document.getElementById("myModal").style.display = "block";
	}
	 </script>';
	
	echo '
	<form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="create_servertask"/>
    <input type="hidden" name="task_type" value="seo_keyword"/>
    <input type="hidden" name="service_primaryid" value="'.$add_campdetails->acamp_id.'"/>
	';
	
	echo '
 <div class="container-fluid">
    <!-- Control the column width, and how they should appear on different devices -->
	  <div class="row" style="padding: 2px;">
      <div class="col-sm-6" style="background-color:#e6ffe6;"><strong>Region:</strong> '.$add_campdetails->region.'</div>
    </div>
	
	  <div class="row" style="padding: 2px;">
      <div class="col-sm-6" style="background-color:#e6ffe6;"><strong>Primary Keyword:</strong> '.$add_campdetails->primary_keyword.'</div>
    </div>
	

	  <div class="row" style="padding: 10px;">
	  <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Generate report </button>
	  </form>
      <div class="col-sm-6" ><a href="'.get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&acamp_id='.$add_campdetails->acamp_id.'"><button class="btn btn-primary"> Edit Keyword </button></a>
	  
	  </div>
    </div>';
	

	  
	 echo ' 
	  </div>
    </div>
 </div>

';



}

function blcfblf_html_saveprimword_savekeywordform($add_campdetails)
{
	
echo '
	
<div class="container">
  <h2><?php blcfblf_d_sub_headermenu1_red("Enter keyword for which you want your website to be top listed in Search Engine Results");?></h2>
  <div class="form-group">
<form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="saveprimword"/>
    <input type="hidden" name="acamp_id" value="'.$add_campdetails->acamp_id.'"/>
	
<select id="region" name="region">
  <option value="usa">USA</option>
  <option value="uk">UK</option>
  <option value="japan">japan</option>
  <option value="india">india</option>
</select>

    <input type="text" name="primary_keyword">
   <button type="submit" class="btn btn-danger">Save</button>
</form>
';
	
}


function blcfblf_html_edit_primword_savekeywordform_locked($add_campdetails)
{
	

	
}


function blcfblf_html_generate_saveprimword_report($off_opt_rep_status,$off_opt_rep_id)
{
	$head='you have not analysed this keyword yet, click below to generate report';
	//blcfblf_d_sub_headermenu1_blue($head);

 //echo $off_opt_rep_id_forid->off_opt_rep_status;
 if($off_opt_rep_status =="pending")
 {
	 
	 echo'
	 <script>
	 function myFunction1(){
    document.getElementById("myModal").style.display = "block";
	}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="create_servertask"/>
    <input type="hidden" name="task_type" value="seo_keyword"/>
    <input type="hidden" name="service_primaryid" value="'.$off_opt_rep_id.'"/>
	 <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Generate report </button>
	 </form>
	 
	 ';

 }

	
}


function blcfblf_useractivate_form1($email)
{
bootstrat_css();
blcfblf_modalpopup("none");
	 echo'
	 <script>
	 function myFunction2() {
		 //alert("asdsa");
    document.getElementById("myModal").style.display = "block";
	}
	 </script>
	 <body>
<div id="myModal" class="modal" onload="myFunction()">
</div>
</body>
	 
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="activate"/>
    Email address :  <input type="email" name="email" id="txt1">
	
	 <button type="submit" class="btn btn-danger" onclick="myFunction2()">Activate</button>
	 </form>
	 
	 ';
	
}


function blcfblf_chart_script($result)
{
$array_data = blcfblf_chart_data($result);	
echo "
 <script type='text/javascript' src='https://www.gstatic.com/charts/loader.js'></script>
    <script type='text/javascript'>
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
      ".$array_data."
        ]);

        var options = {
          title: 'SEO Compitation Analysis',
          curveType: 'function'
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id='curve_chart' style='width: 100%; height: 500px'></div>
  </body>
</html>
";
}
function blcfblf_chart_data($result)
{
$line="['Top Possition'";
$line2="['Top1',";

$counter = 1;
foreach($result as $subtitle)
{
	$line = $line.", '".$subtitle['rowtitle']."'";	
	$counter = $counter + 1;
}
$line= $line."],";


//echo "counter is $counter";



$y = 0;
$line4="";
for($y = 0; $y<=$counter; $y++) {
$i = 0;
$line1="['Top ".($counter - ($counter - $y) + 1)."'";
$line2='';
for($i = 0; $i<= 7; $i++){
	$line2 =$line2.','.$result[$i]['col'][$y];

 // echo $result[$i]['col'][$y].","; 
 // echo "<br>";
 // exit;


}
$line3 = $line1.$line2."],\n";
$line4=$line4.$line3;
}

$result = $line."\n".substr($line4, 0, -2);
return $result;
}



function blcfblf_useractivate_form2($email,$email_vercode)
{
bootstrat_css();
blcfblf_modalpopup("none");
	 echo'
	 <script>
	 function myFunction2() {
		 //alert("asdsa");
    document.getElementById("myModal").style.display = "block";
	}
	 </script>
	 <body>
<div id="myModal" class="modal" onload="myFunction()">
</div>
</body>
	 
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="verify_email"/>
    <input type="hidden" name="email_hidden" value="'.$email.'"/>
   Email  address :<input type="email" value="'.$email.'" name="email" id="txt1" disabled>
   <br>
   <br>
	
Confirmation code  :  <input type="text" name="emailverify_code" value ="'.$email_vercode.'" id="txt2" disabled>
	
	 <button type="submit" class="btn btn-danger" onclick="myFunction2()"> Activate </button>
	 </form>
	 
	 ';
	
}

function blcfblf_preloadinggifimage()
{
	

	echo ' <div class="loading-area">
    <img class="loading-image" src="http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif">
    <p class="loading-text">Loading ...</p>
  </div>  ';
}

function blcfblf_biggif()
{
	echo '
<html>
<head>
<style>
#loading{
position:fixed;
	width: 100%;
	height:100vh;
	background:#fff url(http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif) no-repeat center;
	z-index:99999;

}
</style>
</head>
<body>
<div id ="loading">
</div>
</body>
</html>
';
	
}

function blcfblf_modalpopup($display)
{
echo '
<style>
body {font-family: Arial, Helvetica, sans-serif;}

/* The Modal (background) */
.modal {
  display: '.$display.'; /* Hidden by default block/none */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  padding-top: 100px; /* Location of the box */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: rgb(0,0,0); /* Fallback color */
  background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
 background:#fff url(http://www.downgraf.com/wp-content/uploads/2014/09/01-progress.gif) no-repeat center;

}
</style>
<script>
function myFunction() {
  alert("Page is loaded");
}
</script>

<body>
<div id="myModal" class="modal" onload="myFunction()">
</div>
</body>
</html>
';
}


function check_server_task($localtask_tb_array,$current_url)
{
	global $global_ar;
	global $wpdb;


	//var_dump($localtask_tb_array);
	$user_auth = blcfblf_get_cred1();
	$task_id = $localtask_tb_array[0]->server_task_id;
	$local_task_id = $localtask_tb_array[0]->local_task_id;
	$off_opt_rep_id = $localtask_tb_array[0]->task_type_id;

	
	
	$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				$json_array['task_id']=$task_id;
				//$json_array['task_user_input']=$data[0];
				
			//	echo "<br>";
				
			//	echo "<br>";
				//exit;
	$curl_url=$global_ar['blcfblf_rest_rendpoint'].'taskresponder.php';	
	
	
	$response = json_decode(blcfblf_makeapicall_post($curl_url, $json_array));
	//$response = blcfblf_makeapicall_post($curl_url, $json_array);


	if($response == NULL)
	{
		echo "<br>";
		echo "could not get response from remote server. contact your network adminstrator & developer.";
		exit;
	}
	//echo "<br>";
	//echo "<br>";

	
	$server_task_id=$task_id;
	
	
	$task_eta_datetime=blcfblf_convert_date_time($response->task_details->task_eta_datetime);
	$task_createddate=blcfblf_convert_date_time($response->task_details->task_createddate);
	$task_type=$response->task_details->task_type;
				//$task_createddate=$response->task_details->task_createddate;
	$task_user_input=$response->task_details->task_user_input;
	
	
	$task_output=$response->task_details->task_output;
	//$task_output=$response->task_details->task_output;

	$task_output = esc_sql($task_output);
	
	$task_status=$response->task_details->task_status;
	$task_type_id=$off_opt_rep_id;
	
	$task_type_msg=$response->message;
	$task_type_help=$response->help;
	$task_html_output=$response->task_html_output;
	//$task_html_output = $wpdb->_escape($task_html_output);
	$task_html_output = esc_sql($task_html_output);
	
	$sql_1="UPDATE wp_blcfblf_localtask SET 
	server_task_id = '".$task_id."',
	task_eta_datetime = '".$task_eta_datetime."',
	task_type = '".$task_type."',
	task_user_input = '".$task_user_input."',
	task_output = '".$task_output."',
	task_html_output = '".$task_html_output."',
	task_status = '".$task_status."',
	task_type_msg = '".$task_type_msg."',
	task_type_help = '".$task_type_help."',
	task_type_id = '".$task_type_id."' WHERE local_task_id  = '".$local_task_id."'";
	
	//echo "<br>";
	//echo "<br>";
	//echo "<br>";
	//echo $sql_1;
	//echo "<br>";
	//exit;	
	
	
	//echo $task_output;
	
	//$task_output = substr($task_output, 25);
	//$task_output = substr($task_output,0, -1);
	
	//echo '<pre>';
	//print_r($task_output);
	//echo '</pre>';
	
	//$json_val =json_decode($task_output,true);
	//var_dump($json_val);
	//exit;
	$wpdb->query($wpdb->prepare($sql_1));
	//dbDelta($sql_1);	
	//echo $current_url;
	blcfblf_redirecturl_plugin($current_url);
	//exit;
	/* 
	switch($task_type)
	{
		case 'off_opt_rep':		{
			$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$acamp_id.'&off_opt_rep_id='.$off_opt_rep_id;
			blcfblf_redirecturl_plugin($s_url);
			exit;
		}
		break;
		
		
		case 'seo_keyword':		{
			$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id='.$task_type_id;
			blcfblf_redirecturl_plugin($s_url);
			exit;
		}
		break;
		
		case 'seo_keyword':	
		{
			$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id='.$task_type_id;
			blcfblf_redirecturl_plugin($s_url);
			exit;
		}
		break;
		
		default:
		{
			echo "unknown task . unable to redirect";
		}
		break;
		
	}
	
	if($task_type =="seo_keyword")
	{
		
	}
	 */
	
	/*
	if($response->status == "1")
	{
		//update table task completed and task json data 
		echo "<br>";
		echo "<br>";
		var_dump($response);
	}
	elseif($response->status == "2")
	{
		echo "<br>";
		echo "<br>";
		var_dump($response);
		
	}
	*/
}

function countdown_timer($task_eta_datetime)
{
?>
<!DOCTYPE html>
<html>
  <head>
    <title>JS Counter</title>
    <link rel="stylesheet" type="text/css" href="style.css">
  </head>

  <body onload="incrementCount(10)">
    <div class="main_container" id="id_main_container">
      <div class="container_inner" id="display_div_id">
      </div>
    </div>
  </body>
</html>

<script>
  var counter_list = [10,10000,10000];
  var str_counter_0 = counter_list[0];
  var str_counter_1 = counter_list[1];
  var str_counter_2 = counter_list[2];
  var display_str = "";
  var display_div = document.getElementById("display_div_id");

  function incrementCount(current_count){
    setInterval(function(){
      // clear count
      while (display_div.hasChildNodes()) {
          display_div.removeChild(display_div.lastChild);
      }
      str_counter_0--;
      if (str_counter_0 > 99) {
        str_counter_0 = 0; // reset count
        str_counter_1--;    // increase next count
      }
      if(str_counter_1>99999){
        str_counter_2++;
      }
      display_str = str_counter_2.toString() + str_counter_1.toString() + str_counter_0.toString();
      for (var i = 0; i < display_str.length; i++) {
        var new_span = document.createElement('span');
        new_span.className = 'num_tiles';
        new_span.innerText = display_str[i];
        display_div.appendChild(new_span);
      }
    },1000);
  }
</script>

<?php
}


function display_task_table_html($display_table_html)
{
	/* 
	 
	echo '<pre>';
	print_r($display_table_html);
	echo '</pre>';
	  */
	  
	 if($display_table_html['task_type'] =='off_opt_rep')
	{
		$display_task_header = 'Offline Optimisation Report';
	}
	 
	 
	 if($display_table_html['task_type'] =='seo_keyword')
	{
		$display_task_header = 'SEO Keyword Report';
	}
	 
	 $upgrade_url=get_site_url().'/wp-admin/admin.php?page=blcfblf_activate';
		
		//$display_task_subheader = $display_table_html['task_type_help'];
		$display_task_type_msg = $display_table_html['task_type_msg'];
		if($display_table_html['fulldetails']->task_status != "completed")
		{
			
			
			$display_task_lastupdate = $display_table_html['fulldetails']->task_createddate. " utc time.  ";
			
			$current_time= gmdate("Y-m-d\ H:i:s");
			$eta_time= $display_table_html['task_eta_datetime'];
			$time_diff = blcfblf_datetimedifference($eta_time,$current_time);
			//echo'<script>alert("'.$time_diff.'");</script>';
			
			//echo "time difference is $current_time <br>";
			//echo "time difference is $eta_time <br>";
			//echo "time difference is $time_diff <br>";

			$modal_header_servermsg = $display_task_type_msg;
			$time_diff = $time_diff + 5;//correcting redirection delay
			$TIME_LIMIT = $time_diff;
			$redirect_url = blcfblf_currenturl();
			
			
		
			$notice= '
			<p class="text-primary" align-items="center"><a href ="'.$upgrade_url.'"><button type="button" class="btn btn-danger">Upgrade Now</button></a><br>
			Can not wait for longer time.. </p>
			';
				$modal_header_servermsg = $modal_header_servermsg;
			
			include_once(blcfblf__PLUGIN_DIR."views/display_task_table_html.php");
		}
		else
		{
			
			$display_task_lastupdate = $display_table_html['fulldetails']->task_createddate. " utc time.  ".'<strong>created on : </strong>'.$display_table_html['task_eta_datetime'].' utc time';
			include_once(blcfblf__PLUGIN_DIR."views/display_task_table_html_completed.php");
			//include_once(blcfblf__PLUGIN_DIR."views/display_task_table_off_opt_rep.php");
		}
		
		
	
	
}


function display_task_table_html_single($localtask_tb_array)
{
	
			$display_table_html =array();
			$display_table_html['task_status']= $localtask_tb_array[0]->task_status;
			$display_table_html['task_type_msg']= $localtask_tb_array[0]->task_type_msg;
			$display_table_html['task_output']= $localtask_tb_array[0]->task_output;
			$display_table_html['task_type_help']= $localtask_tb_array[0]->task_type_help;
			$display_table_html['task_eta_datetime']= $localtask_tb_array[0]->task_eta_datetime;
			$display_table_html['task_type']= $localtask_tb_array[0]->task_type ;
			
			//var_dump($display_table_html);
	
	/* 
	 
	echo '<pre>';
	print_r($display_table_html);
	echo '</pre>';
	  */
	  
	 if($display_table_html['task_type'] =='off_opt_rep')
	{
		$display_task_header = 'Offline Optimisation Report';
	}
	 
	 
	 if($display_table_html['task_type'] =='fbacklink')
	{
		$display_task_header = 'Task type : Find Back Links';
	}
	 
	 
	 if($display_table_html['task_type'] =='seo_keyword')
	{
		$display_task_header = 'SEO Keyword Report';
	}
	 
	 
		
		//$display_task_subheader = $display_table_html['task_type_help'];
		$display_task_type_msg = $display_table_html['task_type_msg'];
		
		if($display_table_html['task_status'] != "completed")
		{
			$display_task_lastupdate = $display_table_html['fulldetails']->task_createddate. " utc time.  ".'<strong>will be ready by : </strong>'.$display_table_html['task_eta_datetime'].' utc time';
			include_once(blcfblf__PLUGIN_DIR."views/display_task_table_html.php");
		}
		else
		{
			$display_task_lastupdate = $display_table_html['fulldetails']->task_createddate. " utc time.  ".'<strong>created on : </strong>'.$display_table_html['task_eta_datetime'].' utc time';
			include_once(blcfblf__PLUGIN_DIR."views/display_task_table_html_completed.php");
			//include_once(blcfblf__PLUGIN_DIR."views/display_task_table_off_opt_rep.php");
		}
		
		
	
	
}

function blcfblf_display_htmlcode($html)
{
	echo $html;
}

function blcfblf_html_upgrade_choose_type()
{
	echo '

<h1><span class="badge badge-info">Choose Account Type</span></h1>

							';
 echo'
	 <script>
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="upgrade1"/>
    <input type="hidden" name="task_type" value="off_opt_rep"/>
    <input type="hidden" name="service_primaryid" value="'.$off_opt_rep_id.'"/>
	<label for="account_type">
	<input type="radio" id="account_type" name="account_type" value="pau"> Pay As you use</label>
						  <br>
							<label for="account_type"><input type="radio" id="account_type" name="account_type" value="premium_acount"> Premium Subscription</label>
						  <br>
							<label for="account_type"><input type="radio" id="account_type" name="account_type"  value="gold_acount"> Gold Subscription</label>
						  <br>
						  <br>
	
	 <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Next </button>
	 </form>
	 
	 ';
}


function blcfblf_html_upgrade_choose_type1($case)
{

if($case =="1")
{
	$title='Pay As you use';
}

if($case =="2")
{
	$title='Premium Subscription';
}

if($case =="3")
{
	$title='Gold Subscription';
}
//echo $title;

						
 echo'
	 <script>
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="upgrade2"/>
    <input type="hidden" name="task_type" value="off_opt_rep"/>
    <input type="hidden" name="uptype" value="'.$case.'"/>
	<label for="account_type">Account type: '.$title.'</label>

						  <br>
							<label for="account_type"><input type="radio" id="payment_gatway" name="gw" value="upi"> Pay by UPI (Exclusive for Indians)</label>
							<br>
							<label for="account_type"><input type="radio" id="payment_gatway" name="gw" value="paypalt"> PayPal</label>
						  <br>
							<label for="account_type"><input type="radio" id="payment_gatway" name="gw"  value="bitcoin"> BitCoins</label>
						  <br>
						  <br>
	 <button type="submit" class="btn btn-danger" onclick="myFunction1()"> Next </button>
	 </form>
	 
	 ';
}


function blcfblf_html_upgrade_payu1($case)
{

echo '
<style>
body { margin-top:20px; }
.panel-title {display: inline;font-weight: bold;}
.checkbox.pull-right { margin: 0; }
.pl-ziro { padding-left: 0px; }
</style>

<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Upgrading your account as "Pay As you use" Subscription
                    </h3>
                 </div>
                <div class="panel-body">


';	


	
 echo'
	 <script>
	 
	 function validateForm() {
  var z = document.forms["myForm"]["am"].value;
  
   if(!/^[0-9]+$/.test(z)){
    alert("Please only enter numeric number. Decimal are not accepted")
       return false;
  }
  else
  {
	  myFunction1();
  }
  

}
	 
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form name="myForm" action="'.esc_attr("admin-post.php").'" onsubmit="return validateForm()" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="upgrade2"/>
    <input type="hidden" name="gw" value="payugw"/>
    <input type="hidden" name="uptype" value="'.$case.'"/>';
    echo ' <p class="text-info">You have '.$_SESSION["blcfblf_balance"].' INR balance in your Best Local center account. Recharge your account by adding funds</p><br>';
			
				echo '<label> Enter Amount and recharge your BestLocalcenter account</label> <br>
				<input type="text" id="am" name="am"> INR';
				echo '<br>( minimum 150 INR RS. Maximum 50,000 INR RS )';
				echo "<br>";
				echo "<br>";
			
	
	echo '<button type="submit" class="btn btn-danger" > Add Money </button>
	 </form>
	 
	 ';
	 
	 
	 echo '
	  </div>
            </div>
            <br/>
        </div>
    </div>
</div>

	 ';
}


function blcfblf_html_upgrade_othermembership($case)
{


	
 echo'
	 <script>
	 function myFunction1() {
    document.getElementById("myModal").style.display = "block";
}
	 </script>
	 <form action="'.esc_attr("admin-post.php").'" method="post">
    <input type="hidden" name="action" value="my_action" />
    <input type="hidden" name="form_name" value="upgrade2"/>
    <input type="hidden" name="gw" value="payugw"/>
    <input type="hidden" name="uptype" value="'.$case.'"/>';

 	
	echo '<button type="submit" class="btn btn-danger" onclick="myFunction1()"> Upgrade Now</button>
	 </form>
	 
	 ';
	 
	
}

function sendemail_verification($email,$link)
{
	?>
	<body onload="myFunction_ver()">

    <input type="text" id="email" name="email" value="<?php echo $email;?>"><br>
    <input type="text" id="password" name="password" value="<?php echo $link;?>">

<!-- The core Firebase JS SDK is always required and must be listed first -->

<!-- TODO: Add SDKs for Firebase products that you want to use
     https://firebase.google.com/docs/web/setup#available-libraries -->

<script src="https://www.gstatic.com/firebasejs/8.1.1/firebase-app.js"></script>
<script src="https://www.gstatic.com/firebasejs/8.1.1/firebase-auth.js"></script>
<script>
var firebaseConfig = {
    apiKey: "AIzaSyB4PB1C_bA_oYnzb9Znfbu4f2l_k96efn4",
    authDomain: "bestlocalcenter-889b7.firebaseapp.com",
    databaseURL: "https://bestlocalcenter-889b7.firebaseio.com",
    projectId: "bestlocalcenter-889b7",
    storageBucket: "bestlocalcenter-889b7.appspot.com",
    messagingSenderId: "131835369806",
    appId: "1:131835369806:web:558959e5060ade2e2fe61f"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  
  
function myFunction_ver() {
 
  alert("started");


//signUp();
email_link();		
  
}

function signUp(){
		const auth = firebase.auth();
		var email = document.getElementById("email");
		var password = document.getElementById("password");
		alert(email);
		alert(password);
		
		const promise = auth.createUserWithEmailAndPassword(email.value, password.value);
		promise.catch(e => alert(e.message));
		
		alert("Signed Up");
	}

function email_link()
{
	var email = document.getElementById("email").value;
	var actionCodeSettings = {
    // URL you want to redirect back to. The domain (www.example.com) for this
    // URL must be whitelisted in the Firebase Console.
    url: "http://localhost:3000",
    // This must be true.
    handleCodeInApp: true
  };

firebase
    .auth()
    .sendSignInLinkToEmail(email, actionCodeSettings);


}	

</script>

</body>
	
	<?php
	
}

?>