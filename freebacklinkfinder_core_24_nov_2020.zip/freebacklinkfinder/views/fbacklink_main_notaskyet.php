
<table>
<tr>
<td>
<h6>Primary keyword : </h5>
</td>
<td>
<?php 
//var_dump($fbacklink_id_forid);
//exit;
echo $fbacklink_id_forid->primary_keyword;
?>
</td>
</tr>
<tr>
<td>
<h6>Targeted Url : </h5>
</td>
<td>
<?php echo $fbacklink_id_forid->target_url;?>
</td>
</tr>
<tr>
<td>
<h6>Targeted Region : </h5>
</td>
<td>
<?php echo $fbacklink_id_forid->region;?>
</td>
</tr>
<?php 
//blcfblf_html_generate_off_opt_rep_report("pending",$off_opt_rep_id);
blcfblf_html_generate_fbacklink_report("pending",$fbacklink_id);
blcfblf_modalpopup("none");

?>
</table>

<?php
exit;
?>

