<?php
require_once(ABSPATH.'wp-content/plugins/freebacklinkfinder/includes/definedfun.php');

global $wpdb;
global $global_ar;
//var_dump($global_ar);

//blcfblf_get_cred();

//var_dump($global_ar);

//require_once(ABSPATH.'wp-admin/includes/upgrade.php');

$blcfblf_authcode = $global_ar['blcfblf_authcode'];
$blcfblf_emailid = $global_ar['blcfblf_emailid'];


$r_create_user_api =$global_ar['blcfblf_rest_rendpoint'].'create-user-api.php';
$l_create_user_api =$global_ar['blcfblf_rest_lendpoint'].'sauthupdate';
//echo $r_create_user_api;




//$userstatus ="newuser";
//$userstatus ="newuser";
//echo blcfblf__PLUGIN_URL;
$s_url = get_site_url();
echo '<input type="hidden" id="PLUGIN_URL" name="PLUGIN_URL" value="'.$s_url.'">';
$lauth = 'maheshlauth';
echo '<input type="hidden" id="lauth" name="lauth" value="'.$lauth.'">';


if(($blcfblf_authcode == "dummyauthcode" && $blcfblf_emailid == "dummy@dummy.com" ) ||( $blcfblf_emailid = "" ))
{
	$userstatus='newuser';
}else
{
	$userstatus='existinguser';
}


switch($userstatus){	
	case "newuser":
	{
		//echo "new user";
		include_once(blcfblf__PLUGIN_DIR."views/lic_reg_main.php");
	}
	break;
	case "existinguser";
	{
		//echo "existing user";
		
		echo "<br>";
		$curl= $r_create_user_api = $global_ar['blcfblf_rest_rendpoint'].'plans.php';
		
		
		$res = makeapicall_post($curl, $json_string);
		$res = json_decode($res,true);
		//var_dump($res);
		
		include_once(blcfblf__PLUGIN_DIR."views/existinguser.php");
	}
	break;
	
	default:
	{
		echo "default";
		echo "error occured please reset to start from begining";
	}
	break;
	
}

?>
