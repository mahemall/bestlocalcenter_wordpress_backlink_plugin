<table width="710" border="0" cellpadding="1" cellspacing="1" style="border-width: 0px; background-color: #ffffff;">
<tbody><tr valign="top">
<td colspan="4" style="background-color: #ff9900;">
<p class="rvps1"><span class="rvts2">Search engine ranking factors performance</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #2c5385;">
<p class="rvps1"><span class="rvts4">Ranking Factor Importance</span></p>
</td>
<td width="71" style="background-color: #2c5385;">
<p class="rvps1"><span class="rvts4">Factors Passed</span></p>
</td>
<td width="71" style="background-color: #2c5385;">
<p class="rvps1"><span class="rvts4">Factors Failed</span></p>
</td>
<td rowspan="7" style="background-color: #f6f6f6;">
<p class="rvps2"><img border="0" width="240" height="322" alt="" hspace="1" vspace="1" src="img14.jpg"></p>
<p class="rvps1"><span class="rvts5"><br></span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Essential (weighted most):</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">23</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">8</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Very Important:</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">6</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">7</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Important:</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">36</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">16</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Moderately Important:</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">56</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">5</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Slightly Important:</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">14</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
</tr>
<tr valign="top">
<td width="213" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Total:</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">135</span></p>
</td>
<td width="71" style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">36</span></p>
</td>
</tr>
</tbody></table>