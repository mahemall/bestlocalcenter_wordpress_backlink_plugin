<?php
global $wpdb;
if(!isset($_GET['fbacklink_id']))
{
	echo "error occured contact developer ";
	//redirect & 
	exit;
}
else
{
	//echo "good to go";
	$fbacklink_id = $_GET['fbacklink_id'];
}

$sql_1 ="select * FROM wp_blcfblf_fbacklink WHERE fbacklink_id='$fbacklink_id' AND local_task_id =0";
$fbacklink_tb_array = $wpdb->get_results($sql_1);


if(!empty($fbacklink_tb_array[0]))
{
	//echo "new no task done";
	$switch_case='notaskyet';
	
}
else
{

$sql_1 ="select * FROM wp_blcfblf_fbacklink WHERE fbacklink_id='$fbacklink_id' AND local_task_id !=0";
$fbacklink_tb_array = $wpdb->get_results($sql_1);


$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink' AND task_status='scheduled'";
$localtask_tb_array = $wpdb->get_results($sql_1);

if(!empty($localtask_tb_array[0]))
		{
			//echo "you are here";
			$switch_case='scheduled_inserver';			
		}
		else
		{
			$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink' AND task_status ='extended'";
			$localtask_tb_array = $wpdb->get_results($sql_1);
			if(!empty($localtask_tb_array[0]))
			{
				$switch_case = 'taskextendedbyserver';
			}
			else
			{
				$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink' AND task_status ='canceled'";
				$localtask_tb_array = $wpdb->get_results($sql_1);
				if(!empty($localtask_tb_array[0]))
				{
					$switch_case = 'taskdeniedbyserver';
				}
				else
				{
					$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink' AND task_status ='completed'";
					$localtask_tb_array = $wpdb->get_results($sql_1);
					if(!empty($localtask_tb_array[0]))
					{
						$switch_case = 'completed_by_server';
					}
				}
			}
		}




}

//$switch_case = 'taskextendedbyserver';

if(($switch_case=="taskextendedbyserver") || ($switch_case=="scheduled_inserver"))
{
	$switch_case = 'check_servertask';
	
}



switch($switch_case)
{
	case 'notaskyet':
	{
		include_once(blcfblf__PLUGIN_DIR."views/fbacklink_main_notaskyet.php");
		exit;
	}
	break;
	
	case 'check_servertask':
	{
		
		$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink'";
		$localtask_tb_array = $wpdb->get_results($sql_1);
		
		$server_task_id = $localtask_tb_array[0]->server_task_id;		
		$task_eta_datetime = $localtask_tb_array[0]->task_eta_datetime;	
		$current_time = gmdate("Y-m-d\ H:i:s");		
		$timedifference = blcfblf_datetimedifference($task_eta_datetime,$current_time);
		
		if($timedifference < 0)
		{
			
			$current_url = blcfblf_currenturl();
			check_server_task($localtask_tb_array,$current_url);
		}
		else
		{
			display_task_table_html_single($localtask_tb_array);
			//include_once(blcfblf__PLUGIN_DIR."views/off_opt_rep_main_scheduled_inserver.php");
			exit;
		}
		
		
	}
	break;
	
	case 'completed_by_server':
	{
		$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$fbacklink_tb_array[0]->local_task_id."' AND task_type='fbacklink'";
		$localtask_tb_array = $wpdb->get_results($sql_1);
		display_task_table_html_single($localtask_tb_array);
		$task_html_output = $localtask_tb_array[0]->task_html_output;
		blcfblf_display_htmlcode($task_html_output);
		exit;
		//blcfblf_display_htmlcode($html);
	}
	break;
	
	default:
	{
		echo "Error:unknown task status. Contact developer ";
		exit;
	}
	break;
}
?>