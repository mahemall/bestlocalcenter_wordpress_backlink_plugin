
<div class="container">
          
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Campaign Title</th>
        <th>Targeted Url</th>
        <th>Overal SEO Status</th>
		<th>Page type</th>
        <th>Keywords</th>
        <th>Last Analysed</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>Hello world New</td>
        <td>http://localhost/wp/wp-admin</td>
		<td><div class="progress">
		<div class="progress-bar bg-success" style="width:10%"></div>
		</div></td>
		<td>Post</td>
        <td>Hello world!</td>
        <td>22-10-2020</td>
      </tr>
	  <tr>
        <td>Hello world New <br>edit | delete</td>
        <td>http://localhost/wp/wp-admin</td>
		<td><div class="progress">
		<div class="progress-bar bg-success" style="width:40%"></div>
		</div></td>
		<td>Post</td>
        <td>Hello world!</td>
        <td>22-10-2020</td>
      </tr>
    </tbody>
  </table>
  <ul class="pagination pagination-sm">
  <li class="page-item"><a class="page-link" href="#">Previous</a></li>
  <li class="page-item"><a class="page-link" href="#">1</a></li>
  <li class="page-item"><a class="page-link" href="#">2</a></li>
  <li class="page-item"><a class="page-link" href="#">3</a></li>
  <li class="page-item"><a class="page-link" href="#">Next</a></li>
</ul>

</div>