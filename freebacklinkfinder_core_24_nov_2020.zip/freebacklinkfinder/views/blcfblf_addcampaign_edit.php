<div class="container">
          
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Campaign Title</th>
        <th>Targeted Url</th>
        <th>Overal Campaign Status</th>
		<th>Page type</th>
        <th>Keywords</th>
        <th>Last Analysed</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><?php echo $add_campdetails->camp_title;?></td>
        <td><?php echo $add_campdetails->target_url;?></td>
        <td><div class="progress">
		<div class="progress-bar bg-success" style="width:<?php echo $add_campdetails->seo_status_perc;?>%"></div>
		</div></td>
		<td><?php echo $add_campdetails->post_type;?></td>
        <td><?php echo $add_campdetails->primary_keyword;?></td>
        <td><?php echo $add_campdetails->last_updated_date_time;?></td>
        </tr>
    </tbody>
  </table>
  
<?php
$acamp_id = $add_campdetails->acamp_id;
?>



<a href="<?php echo (get_site_url()."/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id=$acamp_id");?>" ><button type="button" class="btn btn-dark" >Step 1 Understand Compitation</button></a>

<?php 
if (isset($_GET['off_opt_rep_id']))
		{
		$off_opt_rep_id = $_GET['off_opt_rep_id'];
		$url =get_site_url()."/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id=$acamp_id&off_opt_rep_id=$off_opt_rep_id";
		//echo $url;	
		echo "<a href='$url'><button type='button' class='btn btn-dark'>Step 2 Know your position</button></a>";			
		}
		else
		{
			
		$url =get_site_url()."/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id=$acamp_id";
		//echo $url;	
		echo "<a href='$url'><button type='button' class='btn btn-dark'>Step 2 Know your position</button></a>";	
		}

?>

<a href="<?php echo (get_site_url()."/wp-admin/admin.php?page=blcfblf_addcampaign&pg=fbacklink&acamp_id=$acamp_id");?>"><button type="button" class="btn btn-dark">Step 3 Find Resource to compite</button></a>
<a href="<?php echo (get_site_url()."/wp-admin/admin.php?page=blcfblf_addcampaign&pg=fbacklink&acamp_id=$acamp_id");?>"><button type="button" class="btn btn-dark">Step 4 Start compiting</button></a>





