<?php
//include css
blcfblf_html_css_saveprimword();
blcfblf_modalpopup("none");

//var_dump($add_campdetails->local_task_id);
//check localtask =0 
	//if yes enable text box
	//echo strlen($add_campdetails->primary_keyword);
	
	if($add_campdetails->local_task_id == "0" && strlen($add_campdetails->primary_keyword) < 1)
	{
		//$acamp_id = $add_campdetails->acamp_id;
		echo '<h5>Enter the Keyword for which you want your web page to be top listed in google search results</h5>';
		blcfblf_html_saveprimword_savekeywordform($add_campdetails);
	}
	else
	{
		
		blcfblf_html_saveprimword_savekeywordform_locked($add_campdetails);
		echo '<br>';
		
		//blcfblf_html_edit_primword_savekeywordform_locked($add_campdetails);
		
		//blcfblf_html_generate_saveprimword_report("pending",$off_opt_rep_id);
		
	}
	//if no disable it
	
	

?>
