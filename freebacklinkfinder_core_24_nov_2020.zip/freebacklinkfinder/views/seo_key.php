<?php

global $wpdb;
if(!isset($_GET['acamp_id']))
{
	echo "error occured contact developer ";
	//redirect & 
	exit;
}
else
{
	//echo "good to go";
	$acamp_id = $_GET['acamp_id'];
}

$sql_1 ="select * FROM wp_blcfblf_addcampaing WHERE acamp_id='$acamp_id' AND local_task_id =0";
$acamp_id_tb_array = $wpdb->get_results($sql_1);

//var_dump($acamp_id_tb_array);






if(!empty($acamp_id_tb_array[0]))
{
	//echo "new no task done";
	$switch_case='notaskyet';
	
}
else
{


$sql_1 ="select * FROM wp_blcfblf_addcampaing WHERE acamp_id='$acamp_id' AND local_task_id !=0";
$acamp_id_tb_array = $wpdb->get_results($sql_1);


//$acamp_id = $acamp_id_tb_array[0]->acamp_id;




$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword' AND task_status='scheduled'";
$localtask_tb_array = $wpdb->get_results($sql_1);

//var_dump($localtask_tb_array);


		if(!empty($localtask_tb_array[0]))
		{
			//echo "you are here";
			$switch_case='scheduled_inserver';			
		}
		else
		{
			$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword' AND task_status ='extended'";
			$localtask_tb_array = $wpdb->get_results($sql_1);
			if(!empty($localtask_tb_array[0]))
			{
				$switch_case = 'taskextendedbyserver';
			}
			else
			{
				$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword' AND task_status ='canceled'";
				$localtask_tb_array = $wpdb->get_results($sql_1);
				
				if(!empty($localtask_tb_array[0]))
				{
					$switch_case = 'taskdeniedbyserver';
				}
				else
				{
					$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword' AND task_status ='completed'";
					$localtask_tb_array = $wpdb->get_results($sql_1);
					if(!empty($localtask_tb_array[0]))
					{
						$switch_case = 'completed_by_server';
					}
				}
				
				
				
				
				
			}
			
			
		}

}


if(($switch_case=="taskextendedbyserver") || ($switch_case=="scheduled_inserver"))
{
	$switch_case = 'check_servertask';
	
}


//switch to appropriate file

//echo "switch case is $switch_case";


//$switch_case = 'scheduled_inserver';
switch($switch_case)
{
	case 'notaskyet':
	{
		include_once(blcfblf__PLUGIN_DIR."views/seo_keyword_main_notaskyet.php");
		exit;
	}
	break;
	
	
	case 'check_servertask':
	{
		//echo "yes here";
		$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword'";
		$localtask_tb_array = $wpdb->get_results($sql_1);
		
		
		$server_task_id = $localtask_tb_array[0]->server_task_id;		
		$task_eta_datetime = $localtask_tb_array[0]->task_eta_datetime;	
		//$current_time = gmdate("Y-m-d H:i:s");		
		$current_time = current_time( "Y-m-d H:i:s", true );		
		$timedifference = blcfblf_datetimedifference($task_eta_datetime,$current_time);
		/* 
		echo "<br>";
		echo "<br>";
		echo "current eta date time in local server $current_time. ETA time $task_eta_datetime .you have to wait for $timedifference seconds more";
		echo "<br>";
		exit;
		 */
		//if($timedifference < 0)
		if($timedifference < 0 && $localtask_tb_array[0]->task_status !="completed")
		{
			
			
			/* 
			echo "eta time crossed the delivery date time";
			echo "<br>";
			echo "<br>";
			//exit; */
			$current_url = blcfblf_currenturl();
			check_server_task($localtask_tb_array,$current_url);
			//check_server_task($localtask_tb_array,$acamp_id,$acamp_id);
		}
		else
		{
			//echo "still within eta time . please wait $task_eta_datetime";
			$display_table_html =array();
			$display_table_html['task_status']= $localtask_tb_array[0]->task_status;
			$display_table_html['task_type_msg']= $localtask_tb_array[0]->task_type_msg;
			$display_table_html['task_output']= $localtask_tb_array[0]->task_output;
			$display_table_html['task_type_help']= $localtask_tb_array[0]->task_type_help;
			$display_table_html['task_type']= $localtask_tb_array[0]->task_type;
			$display_table_html['task_eta_datetime']= $task_eta_datetime;
			$display_table_html['fulldetails']= $localtask_tb_array[0];
			
			display_task_table_html($display_table_html);
			/* 
			$counter_datetimeformat ="Jan 5, 2021 15:37:25";
			//$counter_datetimeformat ="Nov 5, 2020 02:11:29";
			//$date = new DateTime('2000-01-01');
			$date = new DateTime($task_eta_datetime);
			/* 
			echo "<br>";
			echo $counter_datetimeformat;
			echo "<br>";
			 
			//$modified_date = $date->format('M j, Y H:i:s');
			//$modified_date = ltrim(date('i:s'), 0);
			//$modified_date = ltrim(date($modified_date), 0);
			//echo "mod date ".$modified_date;
			//countdown_timer($modified_date);
			
			 */
		}

		//include_once(blcfblf__PLUGIN_DIR."views/seo_keyword_main_scheduled_inserver.php");
		exit;
	}
	break;
	
	case 'completed_by_server':
	{
		
		//echo "completed_by_server";
		$sql_1 ="select * FROM wp_blcfblf_localtask WHERE local_task_id='".$acamp_id_tb_array[0]->local_task_id."' AND task_type='seo_keyword'";
		
		$localtask_tb_array = $wpdb->get_results($sql_1);
		
		
		
			$display_table_html =array();
			$display_table_html['task_status']= $localtask_tb_array[0]->task_status;
			$display_table_html['task_type_msg']= $localtask_tb_array[0]->task_type_msg;
			$display_table_html['task_output']= $localtask_tb_array[0]->task_output;
			$display_table_html['task_type_help']= $localtask_tb_array[0]->task_type_help;
			$display_table_html['task_type']= $localtask_tb_array[0]->task_type;
			$display_table_html['task_eta_datetime']= $localtask_tb_array[0]->task_eta_datetime;
			$display_table_html['fulldetails']= $localtask_tb_array[0];
			
			display_task_table_html($display_table_html); 
			

			$task_html_output = $localtask_tb_array[0]->task_html_output;
			blcfblf_display_htmlcode($task_html_output);
			//include_once(blcfblf__PLUGIN_DIR."views/seo_keyword_completed_by_server.php");
			
	}
	break;
	
	default:
	{
		echo "default";
		//check_server_task($localtask_tb_array,$acamp_id);
		exit;
		//completed_by_server
	}
	break;
}



exit;
?>

