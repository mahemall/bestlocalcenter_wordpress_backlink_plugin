<?php
require_once(ABSPATH.'wp-content/plugins/freebacklinkfinder/includes/definedfun.php');
global $wpdb;
global $global_ar;

blcfblf_refreshuser();
$s_url = get_site_url();
$s_url = get_site_url().'/wp-admin/edit.php?post_status=publish&post_type=post';
echo '<script> location.replace("'.$s_url.'"); </script>';
exit;

echo "error occured please open a sup[port ticket";

//$gurl =get_site_url().'/wp-admin/admin.php?page=blcfblf_activate&id=off_opt_rep';

bootstrat_css();
echo '<br>';
$details='  Back Link Finder - List Campaign';
$mem_type='Free';
$action_type = 'Upgrade Now';
$status='Active';
blcfblf_d_site_headermenu_gray($details,$mem_type,$status,$action_type);

blcfblf_d_sub_headermenu1_blue($head);
//echo '<br>';


$args = array("posts_per_page" => 10, "orderby" => "comment_count");
	$posts_array = get_posts($args);
	
	//var_dump($posts_array);
	
	foreach($posts_array as $post)
	{
	  echo " $post->post_title";
	  echo "<br>";
	  echo " $post->ID";
	  echo "<br>";

  }
?>