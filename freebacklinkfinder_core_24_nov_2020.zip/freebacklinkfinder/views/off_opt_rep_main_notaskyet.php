
<table>
<tr>
<td>
<h6>Primary keyword : </h5>
</td>
<td>
<?php 
//var_dump($off_opt_rep_id_forid);
echo $off_opt_rep_id_forid->primary_keyword;
?>
</td>
</tr>
<tr>
<td>
<h6>Targeted Url : </h5>
</td>
<td>
<?php echo $off_opt_rep_id_forid->target_url;?>
</td>
</tr>
<tr>
<td>
<h6>Targeted Region : </h5>
</td>
<td>
<?php echo $off_opt_rep_id_forid->region;?>
</td>
</tr>
<?php 
blcfblf_html_generate_off_opt_rep_report("pending",$off_opt_rep_id);
blcfblf_modalpopup("none");

?>
</table>

<?php
exit;
$off_opt_rep_status = $off_opt_rep_id_forid->off_opt_rep_status;
//var_dump($off_opt_rep_id_forid);
switch($off_opt_rep_status)
{
	case 'pending':
	{
		//echo "you are here";
		//exit;
	}
	break;
	
	default :
	{
		
	}
	break;
}


?>



<?php
/*

<tr>
<td>
<h6>SEO Dificulty level : </h5>
</td>
<td>
<?php echo '9';?>
</td>
</tr>
<tr>
<tr>
<td>
<h6>Report Generated on : </h5>
</td>
<td>
<?php echo '21-10-2020';?>
</td>
</tr>
<tr>
<td>
<h6>How Much time it may take to you reach top 10 possition : </h5>
</td>
<td>
<?php echo '10 to 20 days';?>
</td>
</tr>
*/

?>


<table class="table table-bordered">
  <thead align="center" >
    <tr align="center" >
      <th scope="col" align="center" ></th>
      <th scope="col" align="center" >Your Website</th>
      <th scope="col" align="center" >Top 5 Compitators Ranges</th>
      <th scope="col" align="center" >Tools</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th scope="row" align="center">Alexa</th>
      <td align="center">3</td>
      <td align="center" >4 to 600</td>
      <td align="center" >export to Link Manager</td>
    </tr>
    
  </tbody>
</table>

<script>

</script>
