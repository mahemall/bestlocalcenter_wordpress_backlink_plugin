<!DOCTYPE html>
<html lang="en">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
  <h4><?php echo $display_task_header ;?></h4>
  <p><?php echo $display_task_subheader ;?></p>    
<br>  
  <table class="table">
    <tbody>
      <tr>
        <td><strong>Submitted On : </strong><?php echo $display_task_lastupdate ;?></td>
      </tr>
	  <tr>
        <td><strong>Estimate Time of Delivery : </strong><?php echo $display_table_html['task_eta_datetime'] ;?></td>
      </tr>
		<tr>
        <td><strong>Status : </strong><?php echo $display_table_html['task_type_msg'] ;?></td>
      </tr>
    </tbody>
  </table>
</div>

</body>
</html>