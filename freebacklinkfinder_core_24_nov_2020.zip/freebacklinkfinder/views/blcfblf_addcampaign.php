<?php
require_once(ABSPATH.'wp-content/plugins/freebacklinkfinder/includes/definedfun.php');
global $wpdb;
global $global_ar;
$s_url = get_site_url();
//echo $s_url = get_site_url();

//$gurl =get_site_url().'/wp-admin/admin.php?page=blcfblf_activate&id=off_opt_rep';

bootstrat_css();
echo '<br>';
$details='  Back Link Finder - Add Campaign';
$mem_type='Free';
$action_type = 'Upgrade Now';
$status='Active';
blcfblf_d_site_headermenu_gray($details,$mem_type,$status,$action_type);

blcfblf_d_sub_headermenu1_blue($head);
//echo '<br>';
/* start of direct campaingn id */
if(isset($_GET['acamp_id']))
{
	$acamp_id = $_GET['acamp_id'];
	$sql_1 = "select acamp_id FROM wp_blcfblf_addcampaing WHERE acamp_id='$acamp_id'";
	$result = $wpdb->get_results($sql_1);
	$turl = get_permalink($post_id);
	if($result)
	{
	$sql_1 = "select * FROM wp_blcfblf_addcampaing WHERE acamp_id='$acamp_id'";
	$add_campdetails = $wpdb->get_results($sql_1)[0];

	}
	else
	{
		echo "ivalid acamp_id id";
		exit;
	}

	
}
elseif(!isset($_GET['p_id']))
{
	$rd_url = get_site_url().'/wp-admin/edit.php?post_status=publish&post_type=post';
	echo 'Please click on "Back Link Finder" in post dash board for which you need to find back links ';
	echo '<a href="'.$rd_url.'">click here to navigate to published post.</a>';
	exit;
}elseif(isset($_GET['p_id']))
{
	//checking for valid blog post id
		$post_id = $_GET['p_id'];
		$queried_post = get_post($post_id);
		

				//check valid post id
				if($queried_post == NULL)
				{
					$rd_url = get_site_url().'/wp-admin/edit.php?post_status=publish&post_type=post';
					echo 'Invalid request. Please click on "Back Link Finder" in post dash board for which you need to find back links ';
					echo '<a href="'.$rd_url.'">click here to navigate to published post.</a>';
					exit;
				}


				//check post is already published
				if($queried_post->post_status != "publish")
				{
					$rd_url = get_site_url().'/wp-admin/edit.php?post_status=publish&post_type=post';
					echo 'Post should be in publish state . Please click on "Back Link Finder" in post dash board for which you need to find back links ';
					echo '<a href="'.$rd_url.'">click here to navigate to published post.</a>';
					exit;
				}


				//check add campaign table set values

				$sql_1 = "select acamp_id FROM wp_blcfblf_addcampaing WHERE page_id=$post_id AND post_type='post'";
				$result = $wpdb->get_results($sql_1);
				$turl = get_permalink($post_id);
				if($result)
				{
					//update target urldecode
					$sql_1='UPDATE wp_blcfblf_addcampaing SET target_url = "'.$turl.'" WHERE page_id ="'.$post_id.'" AND post_type="post"';
					dbDelta($sql_1);
					//extract & set global variable
					$sql_1 = "select * FROM wp_blcfblf_addcampaing WHERE page_id='$post_id' AND post_type='post'";
					$add_campdetails = $wpdb->get_results($sql_1)[0];
					$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&acamp_id='.$add_campdetails->acamp_id;;
					//echo '<script> location.replace("'.$s_url.'"); </script>';
					blcfblf_redirecturl($s_url);
					exit;
					
				}
				Else
				{
					//insert
					
					$sql_1cr = "INSERT INTO wp_blcfblf_addcampaing (page_id, post_type,target_url, camp_title) VALUES ('$post_id', 'post','$turl','$queried_post->post_title');";
					$result1 = dbDelta($sql_1cr);
						//extracting add camp details for displyaing in further page_id
					$sql_1 = "select * FROM wp_blcfblf_addcampaing WHERE page_id='$post_id' AND post_type='post'";
					$add_campdetails = $wpdb->get_results($sql_1)[0];
					$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&acamp_id='.$add_campdetails->acamp_id;;
					blcfblf_redirecturl($s_url);
					exit;

				}

	


	
}

//blcfblf_d_membertype($mem_type,$status,$action_type);
include_once(blcfblf__PLUGIN_DIR."views/blcfblf_addcampaign_edit.php");
echo "<br>";
echo "<br>";

if($add_campdetails->primary_keyword == null)
{
$add_camp = 'seo_key';
}
else
{
$add_camp=$_GET['pg'];
}
//echo $add_camp;



switch($add_camp){
	
	case 'seo_key':
	{
		include_once(blcfblf__PLUGIN_DIR."views/seo_key.php");
		
	}
	break;
	
	case 'off_opt_rep':
	{
		if (isset($_GET['off_opt_rep_id']))
		{
			//ignoring invalid off_opt_rep_id			
			$off_opt_rep_value = "id_given";
			$off_opt_rep_id = $_GET['off_opt_rep_id'];
			$data_off_opt_rep = get_off_opt_rep_by_off_opt_rep_id($off_opt_rep_id);
			//var_dump($data_off_opt_rep);
			if($data_off_opt_rep['entry'] == 1)
			{
				$off_opt_rep_value = 'id_given';
				$off_opt_rep_id_forid = $data_off_opt_rep['result'][0];
				
				
			}
			else
			{
				echo "invalid off_opt_rep_id given contact developer. ";
			}
		}
		else
		{
			$check_off_opt_rep_by_acamp_id = check_off_opt_rep_by_acamp_id($acamp_id);
			if($check_off_opt_rep_by_acamp_id['entry'] == 0)			{
				$off_opt_rep_value = 'insert_new';				
			}
			elseif($check_off_opt_rep_by_acamp_id['entry'] == 1)
			{
				//var_dump($check_off_opt_rep_by_acamp_id);
				$off_opt_rep_value = 'list';	
					$off_opt_rep_id = $check_off_opt_rep_by_acamp_id['result']->off_opt_rep_id;
					$url=get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$acamp_id.'&off_opt_rep_id='.$off_opt_rep_id;
					blcfblf_redirecturl($url);
					exit;
				
			}

		}
		
		//$off_opt_rep_value='insert_new';
		
		
		
		switch($off_opt_rep_value)
		{
			case 'id_given':
			{
					include_once(blcfblf__PLUGIN_DIR."views/off_opt_rep_main.php");
					exit;
			}
			break;
			
			case 'list':
			{
				//include_once(blcfblf__PLUGIN_DIR."views/off_opt_rep_list.php");
			}
			break;
			
			case 'insert_new':
			{
				//get camp details
				
				$data= blcfblf_get_acamp_from_acamp_id($acamp_id);
				if($data['entry'] = 1)
				{
					$result = $data['result'][0];
					//insert & redirect
					$acamp_id = $acamp_id;
					$target_url = $result->target_url;
					$primary_keyword = $result->primary_keyword;
					$region= $result->region;
					
					
					$sql_1 ="INSERT INTO wp_off_opt_rep (acamp_id,target_url,primary_keyword,region) VALUES ('$acamp_id','$target_url','$primary_keyword','$region');";
					//echo $sql_1;
					dbDelta($sql_1);
					$off_opt_rep_id = $wpdb->insert_id;
					$url=get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$acamp_id.'&off_opt_rep_id='.$off_opt_rep_id;
					blcfblf_redirecturl($url);
				}				 
				
			}
			break;
			
			default :
			{
				
			}
			break;
			
		}
		
		
	}
	break;
	
	case 'online_opt_rep':
	{
		//include_once(blcfblf__PLUGIN_DIR."views/off_opt_rep.php");
		
	}
	break;
	
	case 'fbacklink':
	{
		if (isset($_GET['fbacklink_id']))
		{
			$fbacklink_value = "id_given";
			$fbacklink_id = $_GET['fbacklink_id'];
			$data_off_opt_rep = get_fbacklink_by_fbacklink_id($fbacklink_id);
			
			if($data_off_opt_rep['entry'] == 1)
			{
				$fbacklink_value = 'id_given';
				$fbacklink_id_forid = $data_off_opt_rep['result'][0];
				
				
			}
			else
			{
				echo "invalid off_opt_rep_id given contact developer. ";
			}
			
			
			
		}
		else
		{
			$check_fbacklink_by_acamp_id = check_fbacklink_by_acamp_id($acamp_id);
			if($check_fbacklink_by_acamp_id['entry'] == 0)			{
				$fbacklink_value = 'insert_new';				
			}
			elseif($check_fbacklink_by_acamp_id['entry'] == 1)
			{
				$off_opt_rep_value = 'list';	
					$fbacklink_id = $check_fbacklink_by_acamp_id['result']->fbacklink_id;
					$url=get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=fbacklink&acamp_id='.$acamp_id.'&fbacklink_id='.$fbacklink_id;
					blcfblf_redirecturl($url);
					exit;
			}
		}
		
		switch($fbacklink_value)
		{
			case 'id_given':
			{
					include_once(blcfblf__PLUGIN_DIR."views/fbacklink_main.php");
					exit;
			}
			break;
			
			case 'insert_new':
			{
				$data= blcfblf_get_acamp_from_acamp_id($acamp_id);
				if($data['entry'] = 1)
				{
					$result = $data['result'][0];
					//insert & redirect
					$acamp_id = $acamp_id;
					$target_url = $result->target_url;
					$primary_keyword = $result->primary_keyword;
					$region= $result->region;
					
					
					$sql_1 ="INSERT INTO wp_blcfblf_fbacklink (acamp_id,target_url,primary_keyword,region) VALUES ('$acamp_id','$target_url','$primary_keyword','$region');";
					//echo $sql_1;
					dbDelta($sql_1);
					$fbacklink_id = $wpdb->insert_id;
					$url=get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=fbacklink&acamp_id='.$acamp_id.'&fbacklink_id='.$fbacklink_id;
					blcfblf_redirecturl($url);
				}				 
				
			}
			break;
			
			
		}
		
		
		
		
		//include_once(blcfblf__PLUGIN_DIR."views/fbacklink.php");
	}
	break;
	
	default:
	{
		//echo "default";
		//echo "Error occured inform administrator";
		exit;
	}
	break;
	
}



?>







