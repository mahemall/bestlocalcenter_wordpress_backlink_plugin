
<div class="container">
 
<br>  
  <table class="table">
    <tbody>
      <tr>
        <td><strong>Online Optimisation Score : </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width:70%">
      <span class="sr-only">60% Complete</span>
    </div></td>
      </tr>
		<tr>
        <td><strong>offline Optimisation Score : </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="30" aria-valuemax="100" style="width:10%">
      <span class="sr-only">70% Complete</span>
    </div></td>
	
	<tr>
	<td><strong>SEO Health: </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="30" aria-valuemax="100" style="width:10%">
      <span class="sr-only">70% Complete</span>
    </div>
	</td>
      </tr>
	  
	<tr>
	<td><strong>Backlink Health: </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="30" aria-valuemax="100" style="width:10%">
      <span class="sr-only">70% Complete</span>
    </div>
	</td>
      </tr>
	   
	<tr>
	<td><strong>Ranking Progress: </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="30" aria-valuemax="100" style="width:10%">
      <span class="sr-only">70% Complete</span>
    </div>
	</td>
      </tr>
	   
	<tr>
	<td><strong>Organic traffic progress: </strong> <div class="progress">
    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="30" aria-valuemax="100" style="width:10%">
      <span class="sr-only">70% Complete</span>
    </div>
	</td>
      </tr>
	  
	  
    </tbody>
  </table>
</div>

<table width="710" border="0" cellpadding="1" cellspacing="1" style="border-width: 0px; background-color: #ffffff;">
<tbody><tr valign="top">
<td colspan="13" style="background-color: #ffffff;">
<p class="rvps1"><span class="rvts3">Search term: "Credit debt loan consolidation"</span></p>
</td>
</tr>
<tr valign="top">
<td width="95" style="background-color: #2c5385;">
<p class="rvps1"><span class="rvts4"><br></span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">Your Site</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">1</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">2</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">3</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">4</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">5</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">6</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">7</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">8</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">9</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">10</span></p>
</td>
<td width="80" style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">Range</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Document Title:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">44%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Body Text:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">2%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">H1 Texts:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">50%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Domain:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Page URL:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">57%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">H2-H6 Texts:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">14%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">IMG ALT:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">100%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Bold Text:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">11%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">SD AT:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Outbound AT:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">SD LU:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">4%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Outbound LU:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Meta Descr.:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">15%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
<tr valign="top">
<td style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">First Sentence:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0%</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0%</span></p>
</td>
</tr>
</tbody></table>

<div style="page-break-before: always;"><table width="710" border="0" cellpadding="1" cellspacing="1" style="border-width: 0px; background-color: #ffffff;">
<tbody><tr valign="top">
<td colspan="2" style="background-color: #ffffff;">
<p class="rvps1"><a name="table:-ranking-factors-digest"></a>
<span class="rvts0">Table: Ranking factors digest</span></p>
</td>
</tr>
<tr valign="top">
<td colspan="2">
<p class="rvps1"><span class="rvts13">This chapter shows some of the search engine ranking factors in tabular form. Some of the values may have been abbreviated by using "k" which means that the value must be multiplied by 1000.&nbsp; ("n/a" means "data not available".)</span></p>
</td>
</tr>
</tbody></table>
</div>

<div><table width="710" border="0" cellpadding="1" cellspacing="1" style="border-width: 0px; background-color: #ffffff;">
<tbody><tr valign="top">
<td colspan="13" style="background-color: #ff9900;">
<p class="rvps1"><span class="rvts2">Digest</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #2c5385;">
<p class="rvps1"><span class="rvts4"><br></span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">Your Site</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">1</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">2</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">3</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">4</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">5</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">6</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">7</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">8</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">9</span></p>
</td>
<td style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">10</span></p>
</td>
<td width="80" style="background-color: #2c5385;">
<p class="rvps3"><span class="rvts4">Range</span></p>
</td>
</tr>
<tr valign="top">
<td colspan="13" style="background-color: #ffffff;">
<p class="rvps1"><span class="rvts3">Number of backlinks according to these data providers&nbsp; (the more the better)</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Alexa:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">SEOprofiler:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">200</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">48k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">9k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">667</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">53k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">650</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">2k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">2k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">169k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">6k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">200 to 169k</span></p>
</td>
</tr>
<tr valign="top">
<td colspan="13" style="background-color: #ffffff;">
<p class="rvps1"><span class="rvts3">Mentions on social sites&nbsp; (the more the better)</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Facebook Mentions:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Google +1:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">linkedin:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">0</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">all 0</span></p>
</td>
</tr>
<tr valign="top">
<td colspan="13" style="background-color: #ffffff;">
<p class="rvps1"><span class="rvts3">Other ranking factors results&nbsp; (the older or the lower the better)</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Web Site Age:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Oct 1996</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Apr 2006</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Feb 2009</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">May 2001</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Jul 2007</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Jul 2007</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Jul 1999</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Apr 1997</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">Oct 1996 to Feb 2009</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Server Speed:</span></p>
</td>
<td style="background-color: #99cc00;">
<p class="rvps3"><span class="rvts10">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">n/a</span></p>
</td>
</tr>
<tr valign="top">
<td width="74" style="background-color: #f6f6f6;">
<p class="rvps1"><span class="rvts5">Alexa Traffic Rank:</span></p>
</td>
<td style="background-color: #ea4d5c;">
<p class="rvps3"><span class="rvts12">1,751k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">10k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">3k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">11k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">28k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">2k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">63k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">3k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">3k</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">312</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">202</span></p>
</td>
<td style="background-color: #f6f6f6;">
<p class="rvps3"><span class="rvts5">202 to 63k</span></p>
</td>
</tr>
</tbody></table>
</div>
