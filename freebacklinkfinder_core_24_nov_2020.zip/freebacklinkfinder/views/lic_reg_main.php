<?php
require_once(ABSPATH.'wp-content/plugins/freebacklinkfinder/includes/definedfun.php');
global $wpdb;
global $global_ar;
$s_url = get_site_url();
//echo $s_url = get_site_url();

//$gurl =get_site_url().'/wp-admin/admin.php?page=blcfblf_activate&id=off_opt_rep';

bootstrat_css();
echo '<br>';
$details='  Back Link Finder - Add Campaign';
$mem_type='Free';
$action_type = 'Upgrade Now';
$status='Active';
blcfblf_d_site_headermenu_gray_nosubmenu($details,$mem_type,$status,$action_type);

blcfblf_d_sub_headermenu1_blue($head);

//$email='freesdsa@sadsa.com';


if(isset($_GET['err']))
{
	if( $_GET['err'] == "1")
	{
	echo '<p><strong>Invalid email verification code. please check your email and enter valid email verification code. For assistance contact support center at help@bestlocalcenter.com</strong></p>';
	echo "<br>";
	}
}

if(isset($_GET['pg']))
{
	if(isset($_GET['id']))
	{
		$email=$_GET['id'];
	}
	else
	{
		$email="";
	}
	
	if(isset($_GET['ever']))
	{
		$email_vercode=$_GET['ever'];
	}
	else
	{
		$email_vercode="";
	}
	
	

	if(isset($_SESSION['response']))
	{
	echo '<strong>Check your email and click on verification link that has been sent to  '.$email.' .</strong> . if problem persist contact https://support.bestlocalcenter.com';
	echo "<br>";
	echo "<br>";
	echo $_SESSION['response']['html_code'];
	unset($_SESSION['response']);
	exit;
	
	}
	else
	{
		
			if(isset($_GET['eid']))
			{
				$email=$_GET['eid'];
			}
			else
			{
				$email="";
			}
			
		
		
	echo '<strong>Check your email and click on verification link that has been sent to  '.$email.' . if problem persist contact <a href="https://support.bestlocalcenter.com/open.php" >https://support.bestlocalcenter.com </a> </strong> ';
	echo "<br>";
	echo "<br>";
	
	blcfblf_useractivate_form2($email,$email_vercode);
	exit;	
	}
	
	
}
else
{
	blcfblf_useractivate_form1($email);
}
?>