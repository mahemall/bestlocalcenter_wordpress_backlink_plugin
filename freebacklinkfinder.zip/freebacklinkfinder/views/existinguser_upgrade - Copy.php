<style>
body { margin-top:20px; }
.panel-title {display: inline;font-weight: bold;}
.checkbox.pull-right { margin: 0; }
.pl-ziro { padding-left: 0px; }
</style>
<?php
//blcfblf_preloadergif_start_css();
?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Upgrade Account
                    </h3>
                 </div>
                <div class="panel-body">
                  
							<?php 
							if(isset($_GET['act']))
							{
								$case = $_GET['act'];
								
								blcfblf_html_upgrade_choose_type1($case);
								//exit;
								
							}else
							{
								//$case="0";
								blcfblf_html_upgrade_choose_type($add_campdetails);
								//exit;
							}
							
							
							
							switch($page)
							{
								case "1":
								{
									blcfblf_html_upgrade_choose_type1("sds");
									exit;
									
								}
								break;
								
								case "1":
								{
									//blcfblf_html_upgrade_choose_type1("sds");
									exit;
									
								}
								break;
								
								case "2":
								{
									//blcfblf_html_upgrade_choose_type2();
									exit;
								}
								break;
								
								case "3":
								{
									//blcfblf_html_upgrade_choose_type3();
									exit;
								}
								break;
								
								default:
								{
								
								}
								break;
							}
							
							

?>
                        
                 

                </div>
            </div>
            <br/>
        </div>
    </div>
</div>
