
<section class="pt-5 pb-5" style="">
        <div class="container">
          <div class="row">
            <div class="col">
              <table class="table-responsive table-borderless">
                <thead>
                  <tr>
                    <th scope="col"class="bg-secondary text-white p-2 p-lg-3 border">Services</th>
                    <th scope="col" class="bg-success text-white p-2 p-lg-3 border">Free Account</th>
                    <th scope="col" class="bg-success text-white p-2 p-lg-3 border">Pay as you use</th>
                    <th scope="col" class="bg-success text-white p-2 p-lg-3 border">Premium Subscription</th>
                    <th scope="col" class="bg-success text-white p-2 p-lg-3 border">Gold Subscription</th>
                  </tr>
                </thead>
                <tbody>
				<tr>
                    <th scope="row" style="min-width:225px;" class="bg-white p-2 p-lg-3 border"></th>
                      <td class="bg-white p-2 p-lg-3 border"></td>
                    <td class="bg-white p-2 p-lg-3 border"><a href="<?php echo get_site_url().'/wp-admin/admin.php?page=blcfblf_activate&pg=upg_add';?>"><button type="button" class="btn btn-danger" data-toggle="modal" data-target="#exampleModal"> Upgrade Now </button></a></td>
                    <td class="bg-white p-2 p-lg-3 border"><?php blcfblf_html_upgrade_othermembership("2");?></td>
                    <td class="bg-white p-2 p-lg-3 border"><?php blcfblf_html_upgrade_othermembership("3");?></td>
                   
                  </tr>
				<?php
				foreach ($res as $result) 
				{
					
				   //echo $result['saledate'];
				?>
					<tr>
                    <th scope="row" style="min-width:225px;" class="bg-white p-2 p-lg-3 border"><?php echo $result['title']; ?></th>
                    <td class="bg-white p-2 p-lg-3 border"><?php echo $result['free']; ?></td>
                    <td class="bg-white p-2 p-lg-3 border"><?php echo $result['payu']; ?></td>
                    <td class="bg-white p-2 p-lg-3 border"><?php echo $result['premium']; ?></td>
                    <td class="bg-white p-2 p-lg-3 border"><?php echo $result['gold']; ?></td>
                  </tr>
				<?php
				}
				?>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </section>