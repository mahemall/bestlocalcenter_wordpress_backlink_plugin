
<script>
function ValidateEmail()
{
	document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
	
	
var inputText = document.getElementById("txt1").value;
var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;

        if (reg.test(inputText) == false) 
        {
            document.getElementById("txtHint").innerHTML = inputText + " is not a valid email address. Please enter valid email address.";
			//alert('Invalid Email Address: -'+inputText);
            return false;
        }
		else{
			

			
		showHint();
		return true;	
		}
        
}


function showHint() {
	document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
	var email = document.getElementById("txt1").value;
	var PLUGIN_URL = document.getElementById("PLUGIN_URL").value;
	


  if (email.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  
var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
var theUrl = "<?php echo $r_create_user_api;?>";
xmlhttp.open("POST", theUrl);
xmlhttp.setRequestHeader("Content-Type", "application/json;charset=utf-8");
//xmlhttp.send(JSON.stringify({ "email": "hello@user.com", "domainname": "blc.com", "response": { "name": "Tester" } }));
xmlhttp.send(JSON.stringify({ "email": email, "domainname": PLUGIN_URL, "response": { "name": "Tester" } }));

  xmlhttp.onreadystatechange = function() {

    if (this.readyState == 1) {
      document.getElementById("txtHint").innerHTML = "Please wait validating registry";
    }
	if (this.readyState == 4 && this.status == 200) {
		
      var obj = JSON.parse(this.responseText);
	  document.getElementById("txtHint").innerHTML = obj['message'];
	  var elem = document.getElementById('actbut');
			elem.parentNode.removeChild(elem);
			document.getElementById("txt1").disabled = true;
			 var actbut1 = document.getElementById("actbut1");
			dvPassport.style.display = "block" ;
		
    }
	if (this.readyState == 4 && this.status == 500) {
		
		//xmlhttp.setRequestHeader("athcode", "sdhfakdhka");
		var obj = JSON.parse(this.responseText);
	  document.getElementById("txtHint").innerHTML = obj['message'];
      //document.getElementById("txtHint").innerHTML = this.responseText;
	  if(obj['status'] == 1 ){
		  
		  
		  var elem = document.getElementById('actbut');
			elem.parentNode.removeChild(elem);
			document.getElementById("txt1").disabled = true;
			 var actbut1 = document.getElementById("actbut1");
			dvPassport.style.display = "block" ;
		
			
			
		  
	  }
      
	 
    }
	
  };
 

}

 function int_post(response, url, lauthcode){
	url_rd = '<?php echo $s_url;?>' +'/wp-admin/admin.php?page=blcfblf_activate'; 
	//alert(url_rd);
	 document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
	var xmlhttp = new XMLHttpRequest(); 
	xmlhttp.open("POST", url);
	xmlhttp.setRequestHeader("Content-Type", "application/json;charset=utf-8");
	xmlhttp.send(response);
	
	
	var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
	var theUrl = url;
	xmlhttp.open("POST", theUrl);
	xmlhttp.setRequestHeader("Content-Type", "application/json;charset=utf-8");
	xmlhttp.send(response);
	
	xmlhttp.onreadystatechange = function() {
		
    if (this.readyState == 1) {
      document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
    }
	if (this.readyState == 4 && this.status == 200) {
		true;
		//url_rd
		location.replace(url_rd);
    }
	if (this.readyState == 4 && this.status == 500) {
		location.replace(url_rd);
		
		false;
    }
	
  };
 
	
 }

function Validatecode() {
	document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
	var email = document.getElementById("txt1").value;
	var PLUGIN_URL = document.getElementById("PLUGIN_URL").value;
	var ecode = document.getElementById("txt2").value;
	
	


  if (email.length == 0) { 
    document.getElementById("txtHint").innerHTML = "";
    return;
  }
  
var xmlhttp = new XMLHttpRequest();   // new HttpRequest instance 
var theUrl = "<?php echo $r_create_user_api;?>";
xmlhttp.open("POST", theUrl);
xmlhttp.setRequestHeader("Content-Type", "application/json;charset=utf-8");
//xmlhttp.send(JSON.stringify({ "email": "hello@user.com", "domainname": "blc.com", "response": { "name": "Tester" } }));
xmlhttp.send(JSON.stringify({ "email": email, "domainname": PLUGIN_URL, "emailverify_code": ecode, "response": { "name": "Tester" } }));

  xmlhttp.onreadystatechange = function() {
//alert(this.readyState);
//alert(this.responseText);
//alert(this.status);
    if (this.readyState == 1) {
      document.getElementById("txtHint").innerHTML = "Please wait while we process your request";
    }
	if (this.readyState == 4 && this.status == 200) {
		lauthcode='sds';
		//url= 'http://localhost/wp/wp-json/blcfblf/v1/sauthupdate';
		url= "<?php echo $l_create_user_api;?>";
		if(int_post(this.responseText, url, lauthcode)){
			//alert("updated localdb");
			var obj = JSON.parse(this.responseText);
			document.getElementById("txtHint").innerHTML = obj['message'];
		}
		
		//location.replace("");

      	//alert("palce 1 - with 200");

    }
	if (this.readyState == 4 && this.status == 500) {
		 var obj = JSON.parse(this.responseText);
	  document.getElementById("txtHint").innerHTML = obj['message'];
      //document.getElementById("txtHint").innerHTML = this.responseText;
	  if(obj['status'] == 1 ){
		  
		  var elem = document.getElementById('actbut');
			elem.parentNode.removeChild(elem);
			document.getElementById("txt1").disabled = true;
			 var dvPassport = document.getElementById("dvPassport");
			 var actbut1 = document.getElementById("actbut1");
            dvPassport.style.display = "block" ;
			//alert("palce2 with 500");
			
		  
	  }
      
	 
    }
	
  };
 
 
}


</script>



<html>
<body>
<br>
<br>
<h1>Back Link Finder - Activate your website</h1>
<br>
<span id="txtHint"> Please enter valid email address . Verification code will be sent to email id that you enter below</span>
<br>
<br>

<form action=""> 

Email address :  <input type="email" id="txt1"><button type="button" id="actbut" onclick="ValidateEmail()"style="margin: 5px" >Send Activation Code</button>
<div id="dvPassport" style="display: none">
<br>
Activation Code: <input type="text" id="txt2"><button type="button" id="actbut1" value="yes" onclick="Validatecode()"style="margin: 5px" >Activate Code</button>
</div>
</form>
<br>
</body>
</html>
