<style>
body { margin-top:20px; }
.panel-title {display: inline;font-weight: bold;}
.checkbox.pull-right { margin: 0; }
.pl-ziro { padding-left: 0px; }
</style>
<?php
//blcfblf_preloadergif_start_css();

?>
<link href="//netdna.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//netdna.bootstrapcdn.com/bootstrap/3.0.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<?php


if(isset($_SESSION["response"]))
{
	echo $_SESSION["response"];
	//unset($_SESSION["response"]);
	exit;
}
	
	//var_dump($_SESSION["response"]);
	//exit;
?>
	
<div class="container">
    <div class="row">
        <div class="col-xs-12 col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title">
                        Upgrading your account as "Pay As you use" Subscription
                    </h3>
                 </div>
                <div class="panel-body">
				<?php
				blcfblf_html_upgrade_payu1($case);
				/*
				echo '<h4>You have 10 INR RS balance in your Best Local center account. Recharge your account by adding funds</h4><br>';
			
				echo '<label> Enter Amount</label> <br><input type="text" id="amount" name="amount"> In INR';
				echo '( minimum 150 INR RS. Maximum 50,000 INR RS )';
				echo "<br>";
				echo "<br>";
				echo '<input type="submit" value="Generate Invoice">';
				*/
				?>
				 </div>
            </div>
            <br/>
        </div>
    </div>
</div>
