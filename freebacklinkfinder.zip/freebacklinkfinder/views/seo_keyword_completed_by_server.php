
<html lang="en">
<head>
  <title>free back link generator</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>




<?php

include_once(blcfblf__PLUGIN_DIR."/includes/definedfun.php");

/* 
echo'<pre>';		
print_r($localtask_tb_array[0]->task_output);
echo'</pre>';

 */$main_result = json_decode($localtask_tb_array[0]->task_output,true);
if($main_result == NULL)
{
	echo "Error occured. Report output is invalid. Contact Site developer";
	exit;
}


//chart begining
$list=$main_result ['report_table'];
blcfblf_chart_script($list);

echo "<br>";

echo '<strong>SEO Keyword: </strong>'.$main_result['SEO_Keyword'].'<br><br>';
echo '<strong>Targeted Region: </strong>'.$main_result['Region'].'<br><br>';
echo '<strong>Summary: </strong>'.$main_result['Summary_ttitle'].'<br><br>';

?>
<table id="tablePreview" class="table">
  <thead>
    <tr>
      <th>Possitioning Factor</th>
      <th>Top1</th>
      <th>Top2</th>
      <th>Top3</th>
      <th>Top4</th>
      <th>Top5</th>
      <th>Top6</th>
      <th>Top7</th>
      <th>Top8</th>
      <th>Top9</th>
      <th>Top10</th>
    </tr>
  </thead>
  <!--Table head-->
  <!--Table body-->
  <tbody>
  <?php
  foreach($list as $row){

     echo'
	 <th>'.$row['rowtitle'].'</th>';
	 foreach($row['col'] as $col)
	 {
		echo '<td>'.$col.'</td>'; 
	 }

    echo '</tr>
	';

	}
	?>
   </tbody>
  <!--Table body-->
</table>
<?php
echo '<strong>Check list for Top 10 possitioning</strong>';
echo "<br>";
echo "<br>";
echo $main_result['Summary_detail'].'<br>';
?>