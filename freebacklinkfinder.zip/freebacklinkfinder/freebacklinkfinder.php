<?php
/**
 * @package Free Back Link Finder
 */
/*
Plugin Name: Free Back Link Finder
Plugin URI: http://wpplugin.bestlocalcenter.com/
Description: Used by millions, Free Back Link Finder is a simple easy to use plugin that will find potential back link provider for boasting your SEO Ranking.
Version: 4.1.6
Author: mahemall
Author URI: http://wpplugin.bestlocalcenter.com/
License: GPLv2 or later
Text Domain: Free Back Link Finder
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/


/*
echo plugin_dir_path( __FILE__ );
echo "<br>";
echo plugins_url();

die;
*/
//define('WP_DEBUG_DISPLAY', TRUE);

//echo blcfblf__PLUGIN_URL;



register_activation_hook( __FILE__, array( 'blcfblf', 'plugin_activation' ) );
register_deactivation_hook( __FILE__, array( 'blcfblf', 'plugin_deactivation' ) );
register_activation_hook(__FILE__,'blcfblf_cr_tb_activation');

global $wpdb;
require_once(ABSPATH.'wp-admin/includes/upgrade.php');



define( 'blcfblf_VERSION', '4.1.6' );
define( 'blcfblf__MINIMUM_WP_VERSION', '4.0' );
define( 'blcfblf__PLUGIN_DIR', plugin_dir_path( __FILE__ ) );

//define( 'blcfblf__PLUGIN_URL', plugins_url().'/freebacklinkfinder/' );
define( 'blcfblf_DELETE_LIMIT', 100000 );

function blcfblf_convert_date_time($datestring){
	//$datetime = new DateTime(date("Y-m-d H:i:s")); //"Asia/Calcutta"
	//$date = new DateTime(date("Y-m-d H:i:s"), new DateTimeZone('Asia/Calcutta'));
	//$date = new DateTime($datestring), new DateTimeZone('Asia/Calcutta'));
	//$datetime->add(new DateInterval('PT0H30M00S'));// Here 5 hours, 3 Minutes and 10 seconds is added
	//$task_eta_datetime=$datetime->format('Y-m-d H:i:s');
	return $datestring;
	
}

function add_gvariable($varname)
{		
		global $wpdb;
		require_once(ABSPATH.'wp-admin/includes/upgrade.php');
		
		global $global_ar;
		$global_ar = array();
		if (!session_id()) {
				session_start();
			}
		
		//$global_ar['blcfblf_authcode']= $blcfblf_authcode;
		//$global_ar['blcfblf_emailid']= $blcfblf_emailid;
		//$global_ar['blcfblf_rest_lendpoint']= 'http://localhost/wp/wp-json/blcfblf/v1/';
		//$global_ar['blcfblf_rest_rendpoint']= 'http://localhost/wp/jwtapi/v1/';
		//$global_ar['blcfblf_rest_rendpoint']= 'http://bestlocalcenter.com/wp/jwtapi/v1/';
		$global_ar['blcfblf_rest_rendpoint']= 'https://bestlocalcenter.com/wp/jwtapi/v1/';
		//$global_ar['blcfblf_lauthcode']= 'mahesh';
		$global_ar['plugin_dir']= ABSPATH . 'wp-content/plugins/freebacklinkfinder/';
		

		
		$sql_1='select blcfblf_sauthcode from wp_blcfblf_auth WHERE user ="root"';
		$result = $wpdb->get_var($sql_1);	
		
		if($result)
		{
			$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
			$result1 = $wpdb->get_results($sql_1);
			//var_dump($result1->blcfblf_sauthcode);
		//define( 'blcfblf_authcode', $wpdb->get_var($sql_1));
		$global_ar['blcfblf_authcode'] = $result1[0]->blcfblf_sauthcode;	
		$global_ar['blcfblf_emailid'] = $result1[0]->blcfblf_emailid;	
		$global_ar['membertype'] = $result1[0]->membertype;	
		$global_ar['blcfblf_status'] = $result1[0]->blcfblf_status;	
		//define( 'blcfblf_authcode', $wpdb->get_var($sql_1));
		
		
	
		$_SESSION['blcfblf_emailid'] = $result1[0]->blcfblf_emailid;	
		$_SESSION['membertype'] = $result1[0]->membertype;	
		$_SESSION['blcfblf_status'] = $result1[0]->blcfblf_status;	
		$_SESSION['blcfblf_balance'] = $result1[0]->blcfblf_balance;	
		
		
		
		}
		else
		{
		$global_ar['blcfblf_authcode'] =  "dummyauthcode";	
		$global_ar['blcfblf_emailid'] = "dummy@dummy.com";
		$global_ar['membertype'] = "free";	
		$global_ar['blcfblf_status'] = "pending";	
		
		}
/*
		if($result)
		{
		define( 'blcfblf_authcode', $wpdb->get_var($sql_1));
		$global_ar['blcfblf_authcode'] = $wpdb->get_var($sql_1);		
		}
		else
		{
			//echo "you are gere";
		define( 'blcfblf_authcode', $wpdb->get_var($sql_1));
		global $blcfblf_authcode;
		$global_ar['blcfblf_authcode'] = "dummyauthcode";	
		}
		
		$sql_1='select blcfblf_emailid from wp_blcfblf_auth WHERE user ="root"';
		$result = $wpdb->get_var($sql_1);
		if($result)
		{
		define( 'blcfblf_emailid',  $wpdb->get_var($sql_1) );
		$global_ar['blcfblf_emailid'] = $wpdb->get_var($sql_1);
		}
		else{
		define( 'blcfblf_emailid',  $wpdb->get_var($sql_1) );		
		$global_ar['blcfblf_emailid'] = "dummy@dummy.com";
		}


	*/
}
add_action( 'after_setup_theme', 'add_gvariable' );

/** Step 2 (from text above). */
add_action( 'admin_menu', 'free_Backlink_finder' );

/** Step 1. */
function free_Backlink_finder() {

//adding main menu	
//add_menu_page( "Free Back link Finder", "FBLF_Dashboard", "manage_options", "blcfblf", 'blcfblf_main' ,'');
add_menu_page( "Free Back link Finder" , //page_title
				"Back link Finder" ,	//menu_title
				"manage_options",		//  capability
				"blcfblf", 			// page slug- parent slug
				"blcfblf_sub1", // call back function 
				"", //icon url
				11 // position of buttun
				);
	
	
//** step 4 adding sub menu */

//add_submenu_page( "blcfblf","Free Back link Finder License Activate","License","manage_options","blcfblf_sb1","blcfblf_sub1");

add_submenu_page( "blcfblf", // parent_slug
 "Free Back link Finder DashBoard" ,//$page_title, 
 "DashBoard" ,//$menu_title, 
 "manage_options" , //$capability,
 "blcfblf", // $menu_slug, 
"blcfblf_sub1",//calling function = '',
 1 // $position = null
 );	



add_submenu_page( "blcfblf", // parent_slug
 "Link Manager" ,//$page_title, 
 "Link Manager" ,//$menu_title, 
 "manage_options" , //$capability,
 "blcfblf_addcampaign", // $menu_slug, 
"blcfblf_addcampaign",//calling function = '',
 2 // $position = null
 );	





add_submenu_page( "blcfblf", // parent_slug
 "Activation Key" ,//$page_title, 
 "Activate" ,//$menu_title, 
 "manage_options" , //$capability,
 "blcfblf_activate", // $menu_slug, 
"blcfblf_activate",//calling function = '',
 2 // $position = null
 );	

/*

add_submenu_page( "blcfblf", // parent_slug
 "Link Manager" ,//$page_title, 
 "Link Manager" ,//$menu_title, 
 "manage_options" , //$capability,
 "blcfblf_postmain", // $menu_slug, 
"blcfblf_postmain",//calling function = '',
 2 // $position = null
 );	


*/


}

 	 
function blcfblf_accountexpired_plugin($response,$id)
{
	
	global $global_ar;
	global $wpdb;
	
		$blcfblf_status = $response->blcfblf_status;
		$blcfblf_balance =$response->blcfblf_balance;
		$membertype =$response->membertype;
		
		$sql_1='UPDATE wp_blcfblf_auth SET blcfblf_status = "'.$blcfblf_status.'", blcfblf_balance="'.$blcfblf_balance.'",membertype="'.$membertype.'" WHERE id  = "'.$id.'"';
		//echo $sql_1;
		
		$wpdb->query($wpdb->prepare("$sql_1"));
		$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_activate';
		blcfblf_redirecturl_plugin($s_url);
	
	
}




/** Step 3. */
function blcfblf_main(){
	if ( !current_user_can( 'manage_options' ) )  {
		wp_die( __( 'You do not have sufficient permissions to access this page.' ) );
	}
	//echo '<div class="wrap">';
	//echo '<p>Here is where the form would go if I actually had options.</p>';
	//echo '</div>';
	
}

function blcfblf_sub1(){

	//include_once(blcfblf__PLUGIN_DIR."views/dashboard.php");
	blcfblf_checkuseractivation();
	include_once(blcfblf__PLUGIN_DIR."views/dashboard.php");
	
}

function blcfblf_activate(){
	//refresh wp_blcfblf_auth
	/*
	$user_auth = blcfblf_get_cred_plugin();	
				$task_type = $task_type;
				//var_dump($user_auth);
				$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
	$curl_url=$global_ar['blcfblf_rest_rendpoint'].'userstatus.php';
	//echo $curl_url;
	$response = json_decode(makeapicall_post_plugin($curl_url, $json_array),true);
	if($response['status']=="1")
	{
		//update wp_blcfblf_auth
		$blcfblf_status = $response['blcfblf_status'];
		$blcfblf_balance = $response['blcfblf_balance'];
		$membertype = $response['membertype'];
		$id=$id;
			$sql_1='UPDATE wp_blcfblf_auth SET blcfblf_status = "'.$blcfblf_status.',blcfblf_balance="'.$blcfblf_balance.'",membertype="'.$membertype.'"WHERE id  = "'.$id.'"';
			dbDelta($sql_1);

	}
*/

		
	include_once(blcfblf__PLUGIN_DIR."views/license.php");
	
	
}

function blcfblf_postmain(){
	blcfblf_checkuseractivation();
	include_once(blcfblf__PLUGIN_DIR."views/postmain.php");
	
	
}

function blcfblf_addcampaign(){
	blcfblf_checkuseractivation();
	include_once(blcfblf__PLUGIN_DIR."views/blcfblf_addcampaign.php");
	
	
}

//create table in local database

function blcfblf_cr_tb_activation(){
global $wpdb;
require_once(ABSPATH.'wp-admin/includes/upgrade.php');


//check for authcode new table;

$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
if(count($wpdb->get_var($sql_1))== 0)
{
$sql_1cr = "INSERT INTO ".$wpdb->prefix."options (option_id, option_name, option_value, autoload) VALUES (NULL, 'blcfblf_authcode', 'dummyauthcode', 'no')";
dbDelta($sql_1cr);
}

/*
//check for dummyemail new table;

$sql_1='select option_value from '.$wpdb->prefix.'options WHERE option_name ="blcfblf_emailid"';
if(count($wpdb->get_var($sql_1))==0)
{
$sql_1cr = "INSERT INTO ".$wpdb->prefix."options (option_id, option_name, option_value, autoload) VALUES (NULL, 'blcfblf_emailid', 'dummy@dummy.com', 'no')";
dbDelta($sql_1cr);
}
*/

// wp_blcfblf_localtask
//insert new table;

$sql ='SHOW TABLES LIKE "wp_blcfblf_dash"';
if(count($wpdb->get_var($sql))==0)

$sql_cr = "CREATE TABLE wp_blcfblf_dash (
 id int(255) NOT NULL AUTO_INCREMENT,
 post_id int(255) NOT NULL,
 status enum('active') NOT NULL DEFAULT 'active',
 PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

dbDelta($sql_cr);

$sql ='SHOW TABLES LIKE "wp_blcfblf_addcampaing"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_blcfblf_addcampaing (
  acamp_id int(255) NOT NULL AUTO_INCREMENT,
  local_task_id INT(255) NOT NULL DEFAULT '0',
  page_id int(255) NOT NULL,
  post_type enum('custom','post','page','product') NOT NULL DEFAULT 'custom',
  primary_keyword varchar(255) NOT NULL,
  seo_status_perc int(3) NOT NULL,
  last_updated_date_time datetime NOT NULL DEFAULT current_timestamp(),
  target_url varchar(255) NOT NULL,
  camp_title varchar(255) NOT NULL,
  region varchar(255) NOT NULL,
  PRIMARY KEY (acamp_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);

}

$sql ='SHOW TABLES LIKE "wp_off_opt_rep"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_off_opt_rep (
  off_opt_rep_id int(255) NOT NULL AUTO_INCREMENT,
  local_task_id INT(255) NOT NULL DEFAULT '0',
  acamp_id int(255) NOT NULL,
  off_opt_rep_status enum('pending','scheduled','denied','completed') NOT NULL DEFAULT 'pending',
  primary_keyword varchar(255) NOT NULL,
  seo_status_perc int(3) NOT NULL,
  lastupdate_time datetime NOT NULL DEFAULT current_timestamp(),
  target_url varchar(255) NOT NULL,
  server_msg varchar(255) NOT NULL,
  region varchar(255) NOT NULL,
  PRIMARY KEY (off_opt_rep_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);

}


$sql ='SHOW TABLES LIKE "fbacklink"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_blcfblf_fbacklink (
  fbacklink_id int(255) NOT NULL AUTO_INCREMENT,
  local_task_id INT(255) NOT NULL DEFAULT '0',
  acamp_id int(255) NOT NULL,
  fbacklink_status enum('pending','scheduled','denied','completed') NOT NULL DEFAULT 'pending',
  primary_keyword varchar(255) NOT NULL,
  seo_status_perc int(3) NOT NULL,
  lastupdate_time datetime NOT NULL DEFAULT current_timestamp(),
  target_url varchar(255) NOT NULL,
  server_msg varchar(255) NOT NULL,
  region varchar(255) NOT NULL,
  PRIMARY KEY (fbacklink_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);

}


$sql ='SHOW TABLES LIKE " wp_blcfblf_localtask"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_blcfblf_localtask (
  local_task_id int(255) auto_increment,
  server_task_id int(255) NOT NULL,
  task_eta_datetime datetime NOT NULL DEFAULT current_timestamp(),
  task_type varchar(255) NOT NULL,
  task_createddate datetime NOT NULL DEFAULT current_timestamp(),
  task_user_input longtext NOT NULL,
  task_output longtext NOT NULL,
  task_html_output longtext NOT NULL,
  task_type_msg text NOT NULL,
  task_type_help text NOT NULL,
  task_status varchar(255) NOT NULL,
  task_type_id int(255) NOT NULL,
  PRIMARY KEY (local_task_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);

}



$sql ='SHOW TABLES LIKE "wp_blcfblf_auth"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_blcfblf_auth (
  id int(255) NOT NULL AUTO_INCREMENT,
  user varchar(255) NOT NULL,
  blcfblf_balance FLOAT NOT NULL DEFAULT '0',
  user_limit_json TEXT NOT NULL,
  blcfblf_sauthcode varchar(255) NOT NULL,
  blcfblf_emailid varchar(255) NOT NULL,
  membertype varchar(255) NOT NULL,
  blcfblf_lauthcode varchar(255) NOT NULL,
  blcfblf_status varchar(255) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);

$sql_1cr = "INSERT INTO wp_blcfblf_auth (user, blcfblf_sauthcode, blcfblf_emailid) VALUES ('root', 'dummyauthcode', 'dummy@dummy.com')";
dbDelta($sql_1cr);
}



$sql ='SHOW TABLES LIKE "wp_blcfblf_logs"';
if(count($wpdb->get_var($sql))==0){

$sql_cr = "CREATE TABLE wp_blcfblf_logs (
  log_id int(255) NOT NULL AUTO_INCREMENT,
  created_date datetime NOT NULL DEFAULT current_timestamp(),
  page_name varchar(255) NOT NULL,
  json_data TEXT NOT NULL,
  PRIMARY KEY (log_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";

dbDelta($sql_cr);
}




}

function blcfblf_sauthupdate(){
	global $global_ar;
	$blcfblf_lauthcode=$global_ar['blcfblf_lauthcode'];
	global $wpdb;
	//$post=new wp_Query(args);
	//var_dump($_POST);
	$data = json_decode(file_get_contents("php://input"));
	//var_dump($data);

	if($data->blcfblf_lauthcode == $blcfblf_lauthcode)
	{

	$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
	$result = $wpdb->get_var($sql_1);	
	if(is_countable($result)== 0)
		{
			//update
			//echo "update now";
			$sql_1='UPDATE wp_blcfblf_auth SET blcfblf_status = "'.$data->blcfblf_accountstatus.'", membertype="'.$data->membertype.'",blcfblf_sauthcode = "'.$data->blcfblf_sauthcode.'",blcfblf_emailid="'.$data->blcfblf_emailid.'" WHERE user = "root"';
			//echo $sql_1;
			dbDelta($sql_1);
		}
		else
		{
			//insert
			//echo "insert value	";
			$sql_1 ='INSERT INTO wp_blcfblf_auth (user, blcfblf_status,blcfblf_sauthcode,blcfblf_emailid,membertype) VALUES ("root","'.$data->blcfblf_accountstatus.'","'.$data->blcfblf_sauthcode.'","'.$data->blcfblf_emailid.'","'.$data->membertype.'")';
			//echo $sql_1;
			dbDelta($sql_1);
		}
		
		
		

		//http_response_code(200);
		//return "awesome api mahesh";
		$msg='Sucessfully Updated Registration';
		$help = "For further assistance open support ticket at help@bestloclacenter.com .";
		echo json_encode(array(
											 "status" => 200,
											 "message" => "$msg",
											 "help" => "$help"
										   ));
	}
	
	$res = new WP_REST_Response($response);
    $res->set_status(200);
}

add_action('rest_api_init',function(){
register_rest_route('blcfblf/v1','sauthupdate',[
'methods' => 'POST',
'callback' => 'blcfblf_sauthupdate'
]);

});

/* start post edit option */
/*
 * New columns
 
 */
add_filter('manage_post_posts_columns', 'misha_price_and_featured_columns');
// the above hook will add columns only for default 'post' post type, for CPT:
// manage_{POST TYPE NAME}_posts_columns
function misha_price_and_featured_columns( $column_array ) {
 
	$column_array['price'] = 'Back Link Finder';
	//$column_array['featured'] = 'Featured product';
	// the above code will add columns at the end of the array
	// if you want columns to be added in another place, use array_slice()
 
	return $column_array;
}
 
/*
 * Populate our new columns with data
 */
add_action('manage_posts_custom_column', 'misha_populate_both_columns', 10, 2);
function misha_populate_both_columns( $column_name, $id ) {
	


 
	// if you have to populate more that one columns, use switch()
	switch( $column_name ) :
		case 'price': {
			//echo '$'.get_post_meta( $id, 'product_price', true );
			//echo "Back Link Finder";
			$rd_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign'.'&p_id='.$id;
			//echo '<a href="'.$rd_url.'">Back Link Finder</a>';
			echo '<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">';
			echo '<a href="'.$rd_url.'"><button type="button" class="btn btn-danger">Back Link Finder</button></a>';
			break;
		}
		/*
		case 'featured': {
			if( get_post_meta($id,'product_featured',true) == 'on') 
				echo 'Yes';
			break;
		}
		*/
	endswitch;
 
}


add_action('quick_edit_custom_box',  'misha_quick_edit_fields', 10, 2);
 
function misha_quick_edit_fields( $column_name, $post_type ) {
 
	// you can check post type as well but is seems not required because your columns are added for specific CPT anyway
 
	switch( $column_name ) :
		case 'price': {
 
			// you can also print Nonce here, do not do it ouside the switch() because it will be printed many times
			wp_nonce_field( 'misha_q_edit_nonce', 'misha_nonce' );
 
			// please note: the <fieldset> classes could be:
			// inline-edit-col-left, inline-edit-col-center, inline-edit-col-right
			// each class for each column, all columns are float:left,
			// so, if you want a left column, use clear:both element before
			// the best way to use classes here is to look in browser "inspect element" at the other fields
 
			// for the FIRST column only, it opens <fieldset> element, all our fields will be there
			echo '<fieldset class="inline-edit-col-right">
				<div class="inline-edit-col">
					<div class="inline-edit-group wp-clearfix">';
 
			echo '<label class="alignleft">
					<span class="title">Price</span>
					<span class="input-text-wrap"><input type="text" name="price" value=""></span>
				</label>';
 
			break;
 
		}
		case 'featured': {
 
			echo '<label class="alignleft">
					<input type="checkbox" name="featured">
					<span class="checkbox-title">Featured product</span>
				</label>';
 
			// for the LAST column only - closing the fieldset element
			echo '</div></div></fieldset>';
 
			break;
 
		}
 
	endswitch;
 
}

add_action( 'admin_enqueue_scripts', 'misha_enqueue_quick_edit_population' );
function misha_enqueue_quick_edit_population( $pagehook ) {
 
	// do nothing if we are not on the target pages
	if ( 'edit.php' != $pagehook ) {
		return;
	}
 $populate_url = get_site_url().'/wp-content/plugins/freebacklinkfinder/populate.js';
	wp_enqueue_script( 'populatequickedit', $populate_url, array( 'jquery' ) );
 
}
 /* end post edit option */
 
 
 /* start new add new quick link 
 add_filter( 'post_row_actions', 'remove_row_actions', 10, 1 );
function remove_row_actions( $actions )
{
    if( get_post_type() === 'post' )
        //unset( $actions['edit'] );
        //unset( $actions['view'] );
        //unset( $actions['trash'] );

       // unset( $actions['inline hide-if-no-js'] );
    return $actions;
}
 /* end new add new quick link */
 
 
 /* start working quick link for post edit */
 function hipwee_add_action_button($actions, $post){


//$rd_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign';
$rd_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign'.'&p_id='.$post->ID;
        $actions['export'] = '<a href="'.$rd_url.'"><button type="button" class="btn btn-danger">SEO BLC Tools</button></a>';

    return $actions;
}
add_filter( 'post_row_actions', 'hipwee_add_action_button', 10, 2 );
 /* end working quick link for post edit */
 
 /*start of form processing */
 
add_action( 'admin_post_my_action', 'prefix_admin_my_action' );
add_action( 'admin_post_nopriv_my_action', 'prefix_admin_add_foobar' );

function prefix_admin_add_foobar(){
	echo "no permission ";
	exit;
}

function blcfblf_redirecturl_plugin($url)
{
	echo '<script> location.replace("'.$url.'"); </script>';
	exit;
}


function makeapicall_post_plugin($curl_url, $json_array)
{
	/*
 $form_data = json_decode($_POST['form_data']);
    $data = array(
        'email' => 'free.ibm@gmail.com',
        'domainname' => 'http://localhost/wp/',
          );
*/
$data = $json_array;
$ch = curl_init($curl_url);
# Setup request to send json via POST.
$payload = json_encode( $data );

curl_setopt( $ch, CURLOPT_POSTFIELDS, $payload );
curl_setopt( $ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json','charst:UTF-8'));
# Return response instead of printing.
curl_setopt( $ch, CURLOPT_RETURNTRANSFER, true );
# Send request.
$result = curl_exec($ch);
curl_close($ch);
# Print response.
return $result;
//return json_decode($result);


}


function blcfblf_get_cred_plugin()
{
	global $wpdb;
	global $global_ar;
	require_once(ABSPATH.'wp-admin/includes/upgrade.php');
	$sql_1='select user from wp_blcfblf_auth WHERE user ="root"';
	$result = $wpdb->get_var($sql_1);
	if($result)
		{
			$sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
			
			$result1 = $wpdb->get_results($sql_1);
			
			$cred['blcfblf_authcode']=$result1[0]->blcfblf_sauthcode;
			$cred['blcfblf_emailid']=$result1[0]->blcfblf_emailid;
			$cred['membertype']=$result1[0]->membertype;
			$cred['id']=$result1[0]->id;
			$cred['blcfblf_status']=$result1[0]->blcfblf_status;
			//var_dump($global_ar);
			//print_r($result1[0]->blcfblf_emailid);
		}
		else
		{
		$cred['blcfblf_authcode'] = "dummyauthcode";	
		$cred['blcfblf_emailid'] = "dummy@dummy.com";
		$cred['membertype'] = "free";
		}
		return $cred;
}


function prefix_admin_my_action(){
	global $wpdb;
	global $global_ar;

$action = $_POST['form_name'];

//echo "post is $action";
//exit;	
	switch($action)
	{
		case 'saveprimword':
		{
			$acamp_id = $_POST["acamp_id"];
			$primary_keyword = $_POST["primary_keyword"];
			$region = $_POST["region"];
			$sql_1='UPDATE wp_blcfblf_addcampaing SET primary_keyword = "'.$primary_keyword.'",region = "'.$region.'",seo_status_perc="10" WHERE acamp_id ="'.$acamp_id.'"';
			//var_dump($sql_1);
			dbDelta($sql_1);
			
			$task_type= "saveprimword";
			$service_primaryid= $acamp_id;
			//check if task not created
				//if no			 blcfblf_create_task_inserver($task_type,$service_primaryid);
				$sql ='select * from ';
				//if yes redirect
				
			//perform validation
			//$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&acamp_id='.$acamp_id;
			$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id='.$acamp_id;
			
			//echo '<script> location.replace("'.$s_url.'"); </script>';
			blcfblf_redirecturl_plugin($s_url);
			exit;

		}
		break;
		
		case 'create_servertask':
		{
			//$task_type="off_opt_rep";
			$task_type= $_POST['task_type'];
			$service_primaryid= $_POST['service_primaryid'];
			 blcfblf_create_task_inserver($task_type,$service_primaryid,$_POST);
			 exit;

		}
		break;
		
		case 'activate':
		{
			//var_dump($_POST);
			//not in use
			//sleep(10);
			
			$email=$_POST['email'];
			
			//$sql_1 ="select * from wp_blcfblf_auth WHERE blcfblf_emailid ='$email'";
			//$data = $wpdb->get_results($sql_1);
			$curl_url = $global_ar['blcfblf_rest_rendpoint'].'create-user-api.php';
			$json_array = array();
			$json_array['email']= $email;
			$json_array['domainname']= get_site_url();
			$json_array['requesttype']= "register";
			//echo json_encode($json_array);
			//echo $curl_url;
			//exit;
			//$result = makeapicall_post_plugin($curl_url, $json_array);
			$result = json_decode(makeapicall_post_plugin($curl_url, $json_array));
			if($result == NULL)
			{
				echo "failed to reach server. please contact network administrator ";
			}

			if($result->status == "1")
			{
				//global $blcfblf_postvariable;
				//echo "created new user pending for email activation";
				//$arg1="poorna";
				//do_action( 'add_gvariable', $arg1);
				
					$response=array();
					$response['email']=$result->status;
					$response['link']=$result->status;
					$response['html_code']=$result->html_code;
					$_SESSION['response']=$response;
					$blcfblf_activationemail=$email;					
					$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=email&id=$email";
					//echo $s_url;
					
					//echo '<script> location.replace("'.$s_url.'"); </script>';
					blcfblf_redirecturl_plugin($s_url);
					exit;
				
			}
			else
			{
				echo "ivalid message. please reinstall the plugin and activate";
			}
			exit;
			
		}
		break;
		
		
		case 'verify_email':
		{
			//var_dump($_POST);
			//in use
			//sleep(10);
			
			$email=$_POST['email_hidden'];
			$emailverify_code=$_POST['emailverify_code'];
			
			//$sql_1 ="select * from wp_blcfblf_auth WHERE blcfblf_emailid ='$email'";
			//$data = $wpdb->get_results($sql_1);
			$curl_url = $global_ar['blcfblf_rest_rendpoint'].'create-user-api.php';
			$json_array = array();
			$json_array['email']= $email;
			$json_array['domainname']= get_site_url();
			$json_array['requesttype']= "verify_email";
			$json_array['emailverify_code']= $emailverify_code;
			//echo json_encode($json_array);
			//echo $curl_url;
			
		
			//$result = makeapicall_post_plugin($curl_url, $json_array);
			$result = json_decode(makeapicall_post_plugin($curl_url, $json_array));
		
			if($result->status == "3")
			{
			//2 means success , 1 means invalid
			//update local table and redirect			
 
			//$data=$result->status;
			$blcfblf_status=$result->blcfblf_accountstatus;
			$membertype=$result->membertype;
			$blcfblf_sauthcode=$result->blcfblf_sauthcode;
			$blcfblf_emailid=$result->blcfblf_emailid;
				
	
			 
				 $sql_1='select * from wp_blcfblf_auth WHERE user ="root"';
									$result = $wpdb->get_var($sql_1);	
									if(is_countable($result)== 0)
										{
											//update
											//echo "update now";
											$sql_1='UPDATE wp_blcfblf_auth SET blcfblf_status = "'.$blcfblf_status.'", membertype="'.$membertype.'",blcfblf_sauthcode = "'.$blcfblf_sauthcode.'",blcfblf_emailid="'.$blcfblf_emailid.'" WHERE user = "root"';
											//echo $sql_1;
											dbDelta($sql_1);
										}
										else
										{
											//insert
											//echo "insert value	";
											$sql_1 ='INSERT INTO wp_blcfblf_auth (user, blcfblf_status,blcfblf_sauthcode,blcfblf_emailid,membertype) VALUES ("root","'.$blcfblf_accountstatus.'","'.$blcfblf_sauthcode.'","'.$blcfblf_emailid.'","'.$membertype.'")';
											//echo $sql_1;
											dbDelta($sql_1);
										}
									
				//redirect url		
			
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf";
				//echo $s_url;
				//echo '<script> location.replace("'.$s_url.'"); </script>';
				blcfblf_redirecturl_plugin($s_url);
				exit;	
					
				
			}
			if($result->status == "1")
			{
				$blcfblf_activationemail=$email;					
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=email&id=$email&err=1";
				//echo $s_url;
					
					//echo '<script> location.replace("'.$s_url.'"); </script>';
					blcfblf_redirecturl_plugin($s_url);
					exit;
			}
			exit;
			
		}
		break;
		
		case 'upgrade1':
		{
			if($_POST['account_type']=="pau")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=1";
				
			}
			
			if($_POST['account_type']=="premium_acount")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=2";
				
			}
			
			if($_POST['account_type']=="gold_acount")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=3";
				
			}
			
				//echo $s_url;
					
					//echo '<script> location.replace("'.$s_url.'"); </script>';
					blcfblf_redirecturl_plugin($s_url);
					exit;
			exit;
		}
		break;
		
		case 'upgrade2':
		{
			//var_dump($_POST);
			
			//start request for new task creation
				$user_auth = blcfblf_get_cred_plugin();	
				$task_type = $task_type;
				//var_dump($user_auth);
				$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				
				if(isset($_POST['gw']) && isset($_POST['uptype']))
				{
				$json_array['gw']=$_POST['gw'];
				$json_array['uptype']=$_POST['uptype']; //1 payu, 2 premium 3 gold 4 payu
				$json_array['am']=$_POST['am']; //1 payu, 2 premium 3 gold 4 payu
				$curl_url=$global_ar['blcfblf_rest_rendpoint'].'upgrade.php';
				//echo $curl_url;
				//echo "<br>";
				//echo json_encode($json_array);
				//exit;
				$response = json_decode(makeapicall_post_plugin($curl_url, $json_array),true);	
				
				if(isset($_SESSION["response"]))
				{
					unset($_SESSION["response"]);
				}
				$_SESSION["response"]['htmlcode']=$response['htmlcode'];
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=1";
				blcfblf_redirecturl_plugin($s_url);
					exit;
				}		
				else
				{
					echo "missing mandatory fields ";
					exit;
				}
				
				
			
			exit;
			if($_POST['account_type']=="pau")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=1";
				
			}
			
			if($_POST['account_type']=="premium_acount")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=2";
				
			}
			
			if($_POST['account_type']=="gold_acount")
			{
				$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate&pg=upg&act=3";
				
			}
			
				//echo $s_url;
					
					//echo '<script> location.replace("'.$s_url.'"); </script>';
					blcfblf_redirecturl_plugin($s_url);
					exit;
			exit;
		}
		break;
		
		default:
		{
			sleep(5);
			//echo "Form error occured";
			//exit;
		}
		break;
	}
	
    // Handle request then generate response using echo or leaving PHP and using HTML
}
 
 /*start of form processing */
 
 function blcfblf_create_task_inserver($task_type,$service_primaryid,$post_fields)
 {
	 global $wpdb;
	 global $global_ar;

//check account status if not equal active redirect to activate page
$user_auth = blcfblf_get_cred_plugin();	

if($user_auth['blcfblf_status'] !="active")
{

//echo '<script> location.replace("'.$s_url.'"); </script>';
$s_url = get_site_url()."/wp-admin/admin.php?page=blcfblf_activate";
blcfblf_redirecturl_plugin($s_url);
exit;
}

	switch($task_type)
	{
		case 'off_opt_rep':
		{
			
			$off_opt_rep_id = $service_primaryid;		
			$sql_1 = "SELECT * FROM wp_off_opt_rep WHERE off_opt_rep_id ='$off_opt_rep_id'";
			//$sql_1 = "SELECT * FROM wp_off_opt_rep WHERE off_opt_rep_id ='100'";
			//echo $sql_1;
			$data = $wpdb->get_results($sql_1);
			
			if(empty($data[0]))
			{
				echo "invalid service primary request. contact developer for further assistance";
				echo "<br>";
				echo "after 10 seconds you will be redirected to support page. you can open service request";
				echo "<br>";
				echo "you can click here to redirect";
				$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$acamp_id;
				//echo '<script> location.replace("'.$s_url.'"); </script>';
				blcfblf_redirecturl_plugin($s_url);
				exit;
				
			}
			else
			{
				$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$data[0]->acamp_id.'&off_opt_rep_id='.$data[0]->off_opt_rep_id;
				//echo $s_url;
			
			
			
		//var_dump($data);
		//exit;
		//start check whether local task is already created 
			if($data["local_task_id"]== 0 )
			{
						
				//start request for new task creation
				$user_auth = blcfblf_get_cred_plugin();	
				$task_type = $task_type;
				//var_dump($user_auth);
				$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$id =$user_auth['id'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				$json_array['task_type']=$task_type;
				$json_array['task_user_input']=$data[0];
				//$json_array['blcfblf_emailid']=$user_auth['blcfblf_emailid'];			
				$curl_url=$global_ar['blcfblf_rest_rendpoint'].'taskcreator.php';
		
				//echo $curl_url;
				$response = json_decode(makeapicall_post_plugin($curl_url, $json_array));
				//echo "<br>";
				//echo json_encode($json_array);
				//echo "<br>";
				//$response = makeapicall_post_plugin($curl_url, $json_array);
				if($response == NULL)
				{
				//var_dump($response);
				echo "server failed to respond. please contact network adminsitrator";
				exit;
				}
				else
				{
					if($response->status =="1")
					{
						  
				 
				$server_task_id=$response->task_details->server_task_id;
				$task_eta_datetime=blcfblf_convert_date_time($response->task_details->task_eta_datetime);
				$task_createddate=blcfblf_convert_date_time($response->task_details->task_createddate);
				$task_type=$response->task_details->task_type;
				//$task_createddate=$response->task_details->task_createddate;
				$task_user_input=$response->task_details->task_user_input;
				$task_output=$response->task_details->task_output;
				$task_status=$response->task_details->task_status;
				$task_type_msg=$response->message;
				$task_type_help=$response->help;
				$task_type_id=$off_opt_rep_id;
				
				$sql_1cr = "INSERT INTO wp_blcfblf_localtask(
				server_task_id,
				task_type_id,
				task_eta_datetime,
				task_type,
				task_createddate,
				task_user_input,
				task_output,
				task_type_msg,
				task_type_help,
				task_status
				) VALUES 
				(
				'$server_task_id',
				'$task_type_id',
				'$task_eta_datetime',
				'$task_type',
				'$task_createddate',
				'$task_user_input',
				'$task_output',
				'$task_type_msg',
				'$task_type_help',
				'$task_status'
				)";
				

				dbDelta($sql_1cr);
				$local_task_id = $wpdb->insert_id;
				
			
				if($task_type =="off_opt_rep")
				{
					//echo "<br>";
					$off_opt_rep_id =$data[0]->off_opt_rep_id;
					$sql_1='UPDATE wp_off_opt_rep SET local_task_id = "'.$local_task_id.'"WHERE off_opt_rep_id  = "'.$off_opt_rep_id.'"';
					dbDelta($sql_1);

					//update wp_off_opt_rep table
					
				}
				//redirecting to service page
				blcfblf_redirecturl_plugin($s_url);
			}
					
		if($response->status =="2")
					{
						blcfblf_accountexpired_plugin($response,$id);
						
						
					}
					
					
				}
				/* 
				
				echo "<pre>";
				print_r($response);
				echo "</pre>";
				 */
				//exit; 
				
				
				
			}
			else
			{
				//redirect to status validatoraccordingly
			}
		//end check whether local task is already created 
			
			}
		
		}
		break;
		
		case 'seo_keyword':
		{
			
			$off_opt_rep_id = $service_primaryid;		
			$sql_1 = "SELECT * FROM wp_blcfblf_addcampaing WHERE acamp_id ='$off_opt_rep_id'";
			//$sql_1 = "SELECT * FROM wp_off_opt_rep WHERE off_opt_rep_id ='100'";
			//echo $sql_1;
			$data = $wpdb->get_results($sql_1);
			
			if(empty($data[0]))
			{
				echo "invalid service primary request. contact developer for further assistance";
				echo "<br>";
				echo "after 10 seconds you will be redirected to support page. you can open service request";
				echo "<br>";
				echo "you can click here to redirect";
				$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=off_opt_rep&acamp_id='.$acamp_id;
				//echo '<script> location.replace("'.$s_url.'"); </script>';
				blcfblf_redirecturl_plugin($s_url);
				exit;
				
			}
			else
			{
				
				
				$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id='.$data[0]->acamp_id;
				//echo $s_url;
			
			
			
		//var_dump($data);
		//exit;
		//start check whether local task is already created 
			if($data["local_task_id"]== 0 )
			{
						
				//start request for new task creation
				$user_auth = blcfblf_get_cred_plugin();	
				$task_type = $task_type;
				//var_dump($user_auth);
				$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				$json_array['task_type']=$task_type;
				$json_array['task_user_input']=$data[0];
				//$json_array['blcfblf_emailid']=$user_auth['blcfblf_emailid'];			
				$curl_url=$global_ar['blcfblf_rest_rendpoint'].'taskcreator.php';
		
				
				$response = json_decode(makeapicall_post_plugin($curl_url, $json_array));
				/* 
				
				echo $curl_url;
				echo "<br>";
				echo json_encode($json_array);
				echo "<br>";
				 */
				
				//$response = makeapicall_post_plugin($curl_url, $json_array);
				if($response == NULL)
				{
				//var_dump($response);
				echo "server failed to respond. please contact network adminsitrator";
				exit;
				}
				 /* 
				
				echo "<pre>";
				print_r($response);
				echo "</pre>";
				 
				exit; 
				  */ 
				 if($response->status =="1")
				 {
					 
				
				$server_task_id=$response->task_details->server_task_id;
				$task_eta_datetime=blcfblf_convert_date_time($response->task_details->task_eta_datetime);
				$task_createddate=blcfblf_convert_date_time($response->task_details->task_createddate);
				$task_type=$response->task_details->task_type;
				//$task_createddate=$response->task_details->task_createddate;
				$task_user_input=$response->task_details->task_user_input;
				$task_output=$response->task_details->task_output;
				$task_status=$response->task_details->task_status;
				$task_type_msg=$response->message;
				$task_type_help=$response->help;
				$task_type_id=$off_opt_rep_id;
				
				$sql_1cr = "INSERT INTO wp_blcfblf_localtask(
				server_task_id,
				task_type_id,
				task_eta_datetime,
				task_type,
				task_createddate,
				task_user_input,
				task_output,
				task_type_msg,
				task_type_help,
				task_status
				) VALUES 
				(
				'$server_task_id',
				'$task_type_id',
				'$task_eta_datetime',
				'$task_type',
				'$task_createddate',
				'$task_user_input',
				'$task_output',
				'$task_type_msg',
				'$task_type_help',
				'$task_status'
				)";
				

				dbDelta($sql_1cr);
				$local_task_id = $wpdb->insert_id;
				
			
				if($task_type =="seo_keyword")
				{
					//echo "<br>";
					$acamp_id =$data[0]->acamp_id;
					$sql_1='UPDATE wp_blcfblf_addcampaing SET local_task_id = "'.$local_task_id.'"WHERE acamp_id  = "'.$acamp_id.'"';
				
					dbDelta($sql_1);

					//update wp_off_opt_rep table
					
				}
				//redirecting to service page
				blcfblf_redirecturl_plugin($s_url);
			}
				
				if($response->status =="2")
					{
						$id =$user_auth['id'];
						blcfblf_accountexpired_plugin($response,$id);
						
						
					}
			}
			else
			{
				//redirect to status validatoraccordingly
			}
		//end check whether local task is already created 
			
			}
		
		}
		break;
		
		case 'fbacklink':
		{
			
			$fbacklink_id = $service_primaryid;
			$current_url = $post_fields['current_url'];
					
			$sql_1 = "SELECT * FROM wp_blcfblf_fbacklink WHERE fbacklink_id ='$fbacklink_id'";
			//$sql_1 = "SELECT * FROM wp_off_opt_rep WHERE off_opt_rep_id ='100'";
			//echo $sql_1;
			$data = $wpdb->get_results($sql_1);
			
					
			
			if(empty($data[0]))
			{
				echo "invalid service primary request. contact developer for further assistance";
				echo "<br>";
				echo "after 10 seconds you will be redirected to support page. you can open service request";
				echo "<br>";
				echo "you can click here to redirect";
				//echo '<script> location.replace("'.$s_url.'"); </script>';
				
				//blcfblf_redirecturl_plugin($current_url);
				exit;
				
			}
			else
			{
				
				
				//$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_addcampaign&pg=seo_key&acamp_id='.$data[0]->acamp_id;
				//echo $s_url;
			
			
			
		//var_dump($data);
		//exit;
		//start check whether local task is already created 
			if($data["local_task_id"]== 0 )
			{
						
				//start request for new task creation
				$user_auth = blcfblf_get_cred_plugin();	
				$task_type = $task_type;
				//var_dump($user_auth);
				$json_array=array();
				$json_array['local_account_type']=$user_auth['membertype'];
				$json_array['blcfblf_authcode']=$user_auth['blcfblf_authcode'];
				$json_array['domainname']= get_site_url();
				$json_array['blcfblf_email']=$user_auth['blcfblf_emailid'];
				$json_array['task_type']=$task_type;
				$json_array['task_user_input']=$data[0];
				$json_array['post_input_input']=$post_fields;
				//$json_array['blcfblf_emailid']=$user_auth['blcfblf_emailid'];			
				$curl_url=$global_ar['blcfblf_rest_rendpoint'].'taskcreator.php';
		
				
				$response = json_decode(makeapicall_post_plugin($curl_url, $json_array));
				/*  
				
				echo $curl_url;
				echo "<br>";
				echo json_encode($json_array);
				echo "<br>";
				 exit; 
				 */
				
				//$response = makeapicall_post_plugin($curl_url, $json_array);
				if($response == NULL)
				{
				//var_dump($response);
				echo "server failed to respond. please contact network adminsitrator";
				exit;
				}
				 /* 
				
				echo "<pre>";
				print_r($response);
				echo "</pre>";
				 
				exit; 
				  */ 
				 if($response->status =="1")
				 {
					 
				
				$server_task_id=$response->task_details->server_task_id;
				$task_eta_datetime=blcfblf_convert_date_time($response->task_details->task_eta_datetime);
				$task_createddate=blcfblf_convert_date_time($response->task_details->task_createddate);
				$task_type=$response->task_details->task_type;
				//$task_createddate=$response->task_details->task_createddate;
				$task_user_input=$response->task_details->task_user_input;
				$task_output=$response->task_details->task_output;
				$task_status=$response->task_details->task_status;
				$task_type_msg=$response->message;
				$task_type_help=$response->help;
				$task_type_id=$service_primaryid;
				
				$sql_1cr = "INSERT INTO wp_blcfblf_localtask(
				server_task_id,
				task_type_id,
				task_eta_datetime,
				task_type,
				task_createddate,
				task_user_input,
				task_output,
				task_type_msg,
				task_type_help,
				task_status
				) VALUES 
				(
				'$server_task_id',
				'$task_type_id',
				'$task_eta_datetime',
				'$task_type',
				'$task_createddate',
				'$task_user_input',
				'$task_output',
				'$task_type_msg',
				'$task_type_help',
				'$task_status'
				)";
				

				dbDelta($sql_1cr);
				$local_task_id = $wpdb->insert_id;
				
				$sql_1='UPDATE wp_blcfblf_fbacklink SET local_task_id = "'.$local_task_id.'"WHERE fbacklink_id = "'.$service_primaryid.'"';
				dbDelta($sql_1);
				blcfblf_redirecturl_plugin($current_url);
			}
				if($response->status =="2")
					{
						$id =$user_auth['id'];
						blcfblf_accountexpired_plugin($response,$id);
						
						
					}
			}
			else
			{
				//redirect to status validatoraccordingly
			}
		//end check whether local task is already created 
			
			}
		
		}
		break;
		
		default:
		{
			echo "unknown task type";
			exit;
		}
		break;
		
	}
		
	//make common funtion
		
 }
 
 //
 function blcfblf_checkuseractivation()
 {
	
global $wpdb;
global $global_ar;

$blcfblf_authcode = $global_ar['blcfblf_authcode'];
$blcfblf_emailid = $global_ar['blcfblf_emailid'];
if(($blcfblf_authcode == "dummyauthcode" && $blcfblf_emailid == "dummy@dummy.com" ) ||( $blcfblf_emailid = "" ))
{
	
	$userstatus= false;
	$s_url = get_site_url().'/wp-admin/admin.php?page=blcfblf_activate';
	//echo $s_url;
	
	echo '<script> location.replace("'.$s_url.'"); </script>';
	exit;
	
}
return;
//	

 }
 
